import React from 'react';
import { Calendar, Pill, Activity, FileText, HeartPulse } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const PatientDashboard: React.FC = () => {
  const { user } = useAuth();

  const upcomingAppointments = [
    { id: 1, doctor: 'Dr. Sarah Johnson', specialty: 'Cardiologist', date: '15 Jun 2025', time: '10:00 AM', status: 'Confirmed' },
    { id: 2, doctor: 'Dr. Michael Chen', specialty: 'Dermatologist', date: '22 Jun 2025', time: '2:30 PM', status: 'Pending' },
  ];

  const medications = [
    { id: 1, name: 'Atorvastatin', dosage: '20mg', frequency: 'Once daily', time: 'Evening', remaining: 14 },
    { id: 2, name: 'Metformin', dosage: '500mg', frequency: 'Twice daily', time: 'Morning/Evening', remaining: 22 },
    { id: 3, name: 'Lisinopril', dosage: '10mg', frequency: 'Once daily', time: 'Morning', remaining: 7 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Welcome, {user?.firstName || 'Patient'}</h1>
          <p className="text-gray-600">Here's your health overview</p>
        </div>
        <div className="text-right">
          <p className="text-lg font-medium">{new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>
      </div>

      {/* Health Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-white rounded-xl shadow-sm p-6 flex items-start md:col-span-2">
          <div className="flex-1">
            <div className="flex items-center">
              <HeartPulse className="text-red-500 mr-2" size={24} />
              <h2 className="text-xl font-bold text-gray-800">Health Summary</h2>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-4">
              <div className="border border-gray-200 rounded-lg p-3">
                <p className="text-sm text-gray-500">Blood Pressure</p>
                <p className="text-xl font-semibold text-gray-800">120/80</p>
                <p className="text-xs text-green-600">Normal</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-3">
                <p className="text-sm text-gray-500">Heart Rate</p>
                <p className="text-xl font-semibold text-gray-800">72 BPM</p>
                <p className="text-xs text-green-600">Normal</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-3">
                <p className="text-sm text-gray-500">Blood Sugar</p>
                <p className="text-xl font-semibold text-gray-800">98 mg/dL</p>
                <p className="text-xs text-green-600">Normal</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-3">
                <p className="text-sm text-gray-500">BMI</p>
                <p className="text-xl font-semibold text-gray-800">24.2</p>
                <p className="text-xs text-green-600">Normal</p>
              </div>
            </div>
            <button className="mt-4 text-[#01D48C] hover:text-[#0E1630] transition-colors font-medium text-sm">
              View Full History
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center mb-4">
            <Activity className="text-blue-500 mr-2" size={22} />
            <h2 className="text-xl font-bold text-gray-800">Quick Actions</h2>
          </div>
          <div className="space-y-3">
            <button className="w-full text-left px-4 py-3 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors flex items-center">
              <Calendar className="mr-2" size={18} />
              Book Appointment
            </button>
            <button className="w-full text-left px-4 py-3 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors flex items-center">
              <Pill className="mr-2" size={18} />
              Refill Prescription
            </button>
            <button className="w-full text-left px-4 py-3 bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 transition-colors flex items-center">
              <FileText className="mr-2" size={18} />
              View Test Results
            </button>
          </div>
        </div>
      </div>

      {/* Upcoming Appointments */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center">
            <Calendar className="text-[#01D48C] mr-2" size={22} />
            <h2 className="text-xl font-bold text-gray-800">Upcoming Appointments</h2>
          </div>
          <button className="text-[#01D48C] hover:text-[#0E1630] transition-colors font-medium text-sm">
            View All
          </button>
        </div>
        
        {upcomingAppointments.length > 0 ? (
          <div className="space-y-4">
            {upcomingAppointments.map((appointment) => (
              <div key={appointment.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex flex-wrap justify-between">
                  <div className="mb-2">
                    <h3 className="font-medium text-gray-800">{appointment.doctor}</h3>
                    <p className="text-sm text-gray-600">{appointment.specialty}</p>
                  </div>
                  <div className="text-right mb-2">
                    <p className="text-sm font-medium text-gray-800">{appointment.date}</p>
                    <p className="text-sm text-gray-600">{appointment.time}</p>
                  </div>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    appointment.status === 'Confirmed' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {appointment.status}
                  </span>
                  <div>
                    <button className="text-sm text-gray-600 hover:text-gray-900 mr-3">
                      Reschedule
                    </button>
                    <button className="text-sm text-indigo-600 hover:text-indigo-900">
                      Details
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            No upcoming appointments.
          </div>
        )}
      </div>

      {/* Medications */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center">
            <Pill className="text-[#01D48C] mr-2" size={22} />
            <h2 className="text-xl font-bold text-gray-800">Current Medications</h2>
          </div>
          <button className="text-[#01D48C] hover:text-[#0E1630] transition-colors font-medium text-sm">
            View All
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Medication
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Dosage
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Frequency
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Remaining
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Action
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {medications.map((medication) => (
                <tr key={medication.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="font-medium text-gray-900">{medication.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-gray-700">{medication.dosage}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-gray-700">{medication.frequency}</div>
                    <div className="text-gray-500 text-xs">{medication.time}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-medium rounded-full ${
                      medication.remaining <= 7 
                        ? 'bg-red-100 text-red-800' 
                        : 'bg-green-100 text-green-800'
                    }`}>
                      {medication.remaining} days
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <button className="text-indigo-600 hover:text-indigo-900">
                      Refill
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PatientDashboard;