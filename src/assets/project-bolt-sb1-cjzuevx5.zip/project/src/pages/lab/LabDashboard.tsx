import React from 'react';
import { ClipboardList, AlertTriangle, FileCheck, FlaskRound as Flask, TrendingUp } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const LabDashboard: React.FC = () => {
  const { user } = useAuth();

  const stats = [
    { label: 'Tests Today', value: 32, icon: ClipboardList, color: 'bg-blue-500' },
    { label: 'Pending Results', value: 7, icon: AlertTriangle, color: 'bg-amber-500' },
    { label: 'Completed', value: 25, icon: FileCheck, color: 'bg-green-500' },
    { label: 'Critical Results', value: 2, icon: TrendingUp, color: 'bg-red-500' },
  ];

  const pendingTests = [
    { id: 1, patient: 'Robert Wilson', test: 'Complete Blood Count', urgency: 'Routine', requestedBy: 'Dr. Sarah Chen', status: 'In Progress' },
    { id: 2, patient: 'Maria Garcia', test: 'Lipid Panel', urgency: 'Urgent', requestedBy: 'Dr. James Smith', status: 'Awaiting Sample' },
    { id: 3, patient: 'John Miller', test: 'HbA1c', urgency: 'Routine', requestedBy: 'Dr. Emily Wong', status: 'In Progress' },
    { id: 4, patient: 'Lisa Rodriguez', test: 'Thyroid Function Test', urgency: 'Priority', requestedBy: 'Dr. Michael Johnson', status: 'Sample Collected' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Welcome, {user?.firstName || 'Lab'} Team</h1>
          <p className="text-gray-600">Here's your laboratory overview for today</p>
        </div>
        <div className="text-right">
          <p className="text-lg font-medium">{new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl shadow-sm p-6 flex items-center">
            <div className={`${stat.color} rounded-full p-3 mr-4`}>
              <stat.icon className="text-white" size={22} />
            </div>
            <div>
              <p className="text-gray-600 text-sm">{stat.label}</p>
              <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Pending Tests */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-800">Pending Test Requests</h2>
          <button className="text-[#01D48C] hover:text-[#0E1630] transition-colors font-medium text-sm">
            View All
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Patient
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Test
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Requested By
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Urgency
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Action
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {pendingTests.map((test) => (
                <tr key={test.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="font-medium text-gray-900">{test.patient}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-gray-700">{test.test}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-gray-700">{test.requestedBy}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-medium rounded-full ${
                      test.urgency === 'Urgent' 
                        ? 'bg-red-100 text-red-800' 
                        : test.urgency === 'Priority'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-blue-100 text-blue-800'
                    }`}>
                      {test.urgency}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-gray-700">{test.status}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <button className="text-indigo-600 hover:text-indigo-900 mr-3">
                      Process
                    </button>
                    <button className="text-gray-600 hover:text-gray-900">
                      Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-800">Inventory Status</h2>
          <button className="text-[#01D48C] hover:text-[#0E1630] transition-colors font-medium text-sm">
            Manage Inventory
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 border border-red-200 rounded-lg bg-red-50">
            <div className="flex items-center">
              <Flask className="text-red-500 mr-2" size={20} />
              <h3 className="font-medium text-red-700">Low Stock Items</h3>
            </div>
            <p className="mt-2 text-2xl font-bold text-gray-800">4</p>
            <p className="text-sm text-gray-600">Items need reordering</p>
          </div>
          
          <div className="p-4 border border-amber-200 rounded-lg bg-amber-50">
            <div className="flex items-center">
              <AlertTriangle className="text-amber-500 mr-2" size={20} />
              <h3 className="font-medium text-amber-700">Expiring Soon</h3>
            </div>
            <p className="mt-2 text-2xl font-bold text-gray-800">7</p>
            <p className="text-sm text-gray-600">Items expire within 30 days</p>
          </div>
          
          <div className="p-4 border border-green-200 rounded-lg bg-green-50">
            <div className="flex items-center">
              <FileCheck className="text-green-500 mr-2" size={20} />
              <h3 className="font-medium text-green-700">In Stock</h3>
            </div>
            <p className="mt-2 text-2xl font-bold text-gray-800">127</p>
            <p className="text-sm text-gray-600">Items available</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LabDashboard;