import React from 'react';
import { Calendar, Users, Activity, Clock } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const DoctorDashboard: React.FC = () => {
  const { user } = useAuth();

  const stats = [
    { label: 'Total Patients', value: 157, icon: Users, color: 'bg-blue-500' },
    { label: 'Appointments Today', value: 8, icon: Calendar, color: 'bg-green-500' },
    { label: 'Pending Reports', value: 3, icon: Activity, color: 'bg-amber-500' },
    { label: 'Avg. Consultation', value: '18 min', icon: Clock, color: 'bg-purple-500' },
  ];

  const upcomingAppointments = [
    { id: 1, patient: 'Sarah Johnson', time: '10:00 AM', type: 'Follow-up', status: 'Confirmed' },
    { id: 2, patient: 'Michael Chen', time: '11:30 AM', type: 'New Patient', status: 'Confirmed' },
    { id: 3, patient: 'Emily Rodriguez', time: '2:15 PM', type: 'Test Results', status: 'Pending' },
    { id: 4, patient: 'David Kim', time: '3:45 PM', type: 'Consultation', status: 'Confirmed' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Welcome, Dr. {user?.firstName || 'User'}</h1>
          <p className="text-gray-600">Here's your practice overview for today</p>
        </div>
        <div className="text-right">
          <p className="text-lg font-medium">{new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl shadow-sm p-6 flex items-center">
            <div className={`${stat.color} rounded-full p-3 mr-4`}>
              <stat.icon className="text-white" size={22} />
            </div>
            <div>
              <p className="text-gray-600 text-sm">{stat.label}</p>
              <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Appointments */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-800">Today's Appointments</h2>
          <button className="text-[#01D48C] hover:text-[#0E1630] transition-colors font-medium text-sm">
            View All
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Patient
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Time
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Action
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {upcomingAppointments.map((appointment) => (
                <tr key={appointment.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="font-medium text-gray-900">{appointment.patient}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-gray-700">{appointment.time}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-gray-700">{appointment.type}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-medium rounded-full ${
                      appointment.status === 'Confirmed' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {appointment.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <button className="text-indigo-600 hover:text-indigo-900 mr-3">
                      View
                    </button>
                    <button className="text-gray-600 hover:text-gray-900">
                      Reschedule
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DoctorDashboard;