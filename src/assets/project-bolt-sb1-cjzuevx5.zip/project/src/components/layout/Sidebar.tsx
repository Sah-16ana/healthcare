import React, { useState, useEffect } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { 
  Home, 
  Calendar, 
  ShoppingBag, 
  Shield, 
  AlertTriangle, 
  Settings, 
  LogOut,
  ChevronLeft,
  ChevronRight,
  FileText,
  Microscope,
  Users,
  Activity,
  HeartPulse,
  FlaskConical,
  ClipboardList
} from "lucide-react";
import { useAuth } from "../../context/AuthContext";

type MenuItem = {
  icon: React.ElementType;
  label: string;
  path: string;
};

const Sidebar: React.FC = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const toggleSidebar = () => setIsCollapsed(!isCollapsed);

  // Define menu items for each role
  const doctorMenuItems: MenuItem[] = [
    { icon: Home, label: "Dashboard", path: "/doctor" },
    { icon: Calendar, label: "Appointments", path: "/doctor/appointments" },
    { icon: Users, label: "Patients", path: "/doctor/patients" },
    { icon: FileText, label: "Prescriptions", path: "/doctor/prescriptions" },
    { icon: Activity, label: "Reports", path: "/doctor/reports" },
    { icon: Settings, label: "Settings", path: "/doctor/settings" },
  ];

  const labMenuItems: MenuItem[] = [
    { icon: Home, label: "Dashboard", path: "/lab" },
    { icon: ClipboardList, label: "Test Orders", path: "/lab/orders" },
    { icon: Microscope, label: "Test Reports", path: "/lab/reports" },
    { icon: FlaskConical, label: "Inventory", path: "/lab/inventory" },
    { icon: Calendar, label: "Schedule", path: "/lab/schedule" },
    { icon: Settings, label: "Settings", path: "/lab/settings" },
  ];

  const patientMenuItems: MenuItem[] = [
    { icon: Home, label: "Dashboard", path: "/patient" },
    { icon: Calendar, label: "Appointments", path: "/patient/appointments" },
    { icon: HeartPulse, label: "Health Records", path: "/patient/records" },
    { icon: ShoppingBag, label: "Pharmacy", path: "/patient/pharmacy" },
    { icon: Shield, label: "Insurance", path: "/patient/insurance" },
    { icon: AlertTriangle, label: "Emergency", path: "/patient/emergency" },
    { icon: Settings, label: "Settings", path: "/patient/settings" },
  ];

  // Select menu items based on user role
  const getMenuItems = (): MenuItem[] => {
    switch (user?.userType) {
      case "doctor":
        return doctorMenuItems;
      case "lab":
        return labMenuItems;
      case "patient":
        return patientMenuItems;
      default:
        return patientMenuItems;
    }
  };

  const menuItems = getMenuItems();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div
      className={`h-screen text-[#F5F5F5] bg-[#0E1630] p-4 flex flex-col rounded-xl shadow-xl transition-all duration-300 ${
        isCollapsed ? "w-20" : "w-60"
      }`}
    >
      {/* Sidebar Header */}
      <div className="flex items-center justify-between mb-8">
        <div className={`flex items-center ${isCollapsed ? "justify-center w-full" : ""}`}>
          <h2 className="text-[#0E1630] text-lg bg-[#F4C430] p-1 rounded-full h-9 w-9 flex items-center justify-center font-bold">AV</h2>
          {!isCollapsed && (
            <h2 className="text-lg ml-3 font-bold text-[#F5F5F5]">Swasthya</h2>
          )}
        </div>
        <button
          onClick={toggleSidebar}
          className={`text-[#F5F5F5] hover:bg-slate-700 p-1 rounded-full transition-colors ${isCollapsed ? "mx-auto mt-4" : ""}`}
        >
          {isCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
        </button>
      </div>

      {/* Profile Section */}
      <div className={`flex items-center mb-6 ${isCollapsed ? "justify-center" : ""}`}>
        <div className="relative">
          <img
            src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150"
            alt="User Avatar"
            className="w-10 h-10 rounded-full border border-gray-500 shadow-lg"
          />
          <span className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-green-500 border-2 border-[#0E1630] rounded-full ${isCollapsed ? "block" : "block"}`}></span>
        </div>
        {!isCollapsed && (
          <div className="ml-3 overflow-hidden">
            <p className="text-sm font-medium truncate">
              {user?.userType === "doctor" ? "Dr. " : ""}{user?.firstName || user?.userType || "User"}
            </p>
            <p className="text-xs text-gray-400 capitalize truncate">
              {user?.userType || "User"}
            </p>
          </div>
        )}
      </div>

      {!isCollapsed && <div className="border-t border-gray-700 my-4"></div>}

      {/* Menu Items */}
      <ul className="flex-1 space-y-1 mt-4">
        {menuItems.map((item, index) => (
          <li key={index}>
            <NavLink
              to={item.path}
              className={({ isActive }) =>
                `flex items-center py-3 px-3 rounded-lg cursor-pointer transition-all duration-200 ${
                  isCollapsed ? "justify-center" : ""
                } ${
                  isActive
                    ? "bg-[#01D48C] text-[#0e1630] font-medium"
                    : "text-[#F5F5F5] hover:bg-gray-700 hover:text-white"
                }`
              }
            >
              <item.icon size={isCollapsed ? 20 : 18} strokeWidth={2} />
              {!isCollapsed && <span className="ml-3 text-sm">{item.label}</span>}
            </NavLink>
          </li>
        ))}
      </ul>

      {/* Logout */}
      <div
        className="flex items-center py-3 px-3 mt-4 rounded-lg cursor-pointer transition-all duration-200 text-red-400 hover:bg-red-500/20 hover:text-red-300"
        onClick={handleLogout}
      >
        <LogOut size={isCollapsed ? 20 : 18} strokeWidth={2} className={isCollapsed ? "mx-auto" : ""} />
        {!isCollapsed && <span className="ml-3 text-sm">Logout</span>}
      </div>
    </div>
  );
};

export default Sidebar;