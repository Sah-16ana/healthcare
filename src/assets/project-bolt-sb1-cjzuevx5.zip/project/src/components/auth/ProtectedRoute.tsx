import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types/auth';

interface ProtectedRouteProps {
  allowedRoles?: UserRole[];
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  allowedRoles = ['doctor', 'lab', 'patient']
}) => {
  const { isAuthenticated, user, isLoading } = useAuth();

  // Show loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-12 h-12 border-4 border-t-[#01D48C] border-gray-200 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Check if user is authenticated
  if (!isAuthenticated || !user) {
    return <Navigate to="/login" replace />;
  }

  // Check if user has required role
  if (allowedRoles.length > 0 && !allowedRoles.includes(user.userType)) {
    // Redirect to the appropriate dashboard based on their actual role
    if (user.userType === 'doctor') {
      return <Navigate to="/doctor" replace />;
    } else if (user.userType === 'lab') {
      return <Navigate to="/lab" replace />;
    } else {
      return <Navigate to="/patient" replace />;
    }
  }

  return <Outlet />;
};

export default ProtectedRoute;