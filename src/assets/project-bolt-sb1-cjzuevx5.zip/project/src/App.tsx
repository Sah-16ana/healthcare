import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';

// Layouts
import DashboardLayout from './components/layout/DashboardLayout';

// Auth Components
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import ProtectedRoute from './components/auth/ProtectedRoute';

// Dashboard Pages
import DoctorDashboard from './pages/doctor/DoctorDashboard';
import LabDashboard from './pages/lab/LabDashboard';
import PatientDashboard from './pages/patient/PatientDashboard';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          
          {/* Doctor Routes */}
          <Route element={<ProtectedRoute allowedRoles={['doctor']} />}>
            <Route element={<DashboardLayout />}>
              <Route path="/doctor" element={<DoctorDashboard />} />
              <Route path="/doctor/appointments" element={<div>Doctor Appointments Page</div>} />
              <Route path="/doctor/patients" element={<div>Doctor Patients Page</div>} />
              <Route path="/doctor/prescriptions" element={<div>Doctor Prescriptions Page</div>} />
              <Route path="/doctor/reports" element={<div>Doctor Reports Page</div>} />
              <Route path="/doctor/settings" element={<div>Doctor Settings Page</div>} />
            </Route>
          </Route>
          
          {/* Lab Routes */}
          <Route element={<ProtectedRoute allowedRoles={['lab']} />}>
            <Route element={<DashboardLayout />}>
              <Route path="/lab" element={<LabDashboard />} />
              <Route path="/lab/orders" element={<div>Lab Orders Page</div>} />
              <Route path="/lab/reports" element={<div>Lab Reports Page</div>} />
              <Route path="/lab/inventory" element={<div>Lab Inventory Page</div>} />
              <Route path="/lab/schedule" element={<div>Lab Schedule Page</div>} />
              <Route path="/lab/settings" element={<div>Lab Settings Page</div>} />
            </Route>
          </Route>
          
          {/* Patient Routes */}
          <Route element={<ProtectedRoute allowedRoles={['patient']} />}>
            <Route element={<DashboardLayout />}>
              <Route path="/patient" element={<PatientDashboard />} />
              <Route path="/patient/appointments" element={<div>Patient Appointments Page</div>} />
              <Route path="/patient/records" element={<div>Patient Records Page</div>} />
              <Route path="/patient/pharmacy" element={<div>Patient Pharmacy Page</div>} />
              <Route path="/patient/insurance" element={<div>Patient Insurance Page</div>} />
              <Route path="/patient/emergency" element={<div>Patient Emergency Page</div>} />
              <Route path="/patient/settings" element={<div>Patient Settings Page</div>} />
            </Route>
          </Route>
          
          {/* Default Redirects */}
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;