import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useSearch } from '../context/SearchContext';
import { ShoppingCartIcon, MagnifyingGlassIcon, DocumentArrowUpIcon } from '@heroicons/react/24/outline';

function Header() {
  const { cart } = useCart();
  const { searchTerm, setSearchTerm } = useSearch();

  return (
    <header className="bg-[#1e3a8a] text-white shadow-lg">
      <div className="container mx-auto px-4 py-4 max-w-6xl">
        <div className="flex items-center justify-between mb-4">
          <Link to="/" className="text-2xl font-bold">LabTest</Link>
          <div className="flex items-center gap-6">
            <button className="flex items-center gap-2">
              <DocumentArrowUpIcon className="w-6 h-6" />
              Upload Prescription
            </button>
            <Link to="/cart" className="flex items-center gap-2">
              <ShoppingCartIcon className="w-6 h-6" />
              <span className="bg-[#fbbf24] text-black px-2 rounded-full">
                {cart.length}
              </span>
            </Link>
          </div>
        </div>
        <div className="relative">
          <MagnifyingGlassIcon className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="search"
            placeholder="Search for tests, packages and more..."
            className="w-full px-10 py-2 rounded-lg bg-white text-gray-800"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
    </header>
  );
}

export default Header;