import { useCart } from '../context/CartContext';
import { useNavigate } from 'react-router-dom';

function CartPage() {
  const { cart, setCart } = useCart();
  const navigate = useNavigate();

  const removeFromCart = (id) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const handleCheckout = () => {
    if (cart.length > 0) {
      navigate(`/labs/${cart[0].id}`);
    }
  };

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-[#1e3a8a]">Your Cart</h1>
      {cart.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <p className="text-gray-600">Your cart is empty</p>
        </div>
      ) : (
        <>
          <div className="space-y-4">
            {cart.map(item => (
              <div key={item.id} className="bg-white rounded-lg shadow-md p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-lg font-semibold text-[#1e3a8a]">{item.name}</h2>
                    <p className="text-gray-600 mt-1">{item.description}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-2xl font-bold text-[#1e3a8a]">₹{item.price}</span>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="block mt-2 text-red-600 hover:text-red-700"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex justify-between items-center mb-4">
              <span className="text-lg font-semibold text-[#1e3a8a]">Total</span>
              <span className="text-2xl font-bold text-[#1e3a8a]">₹{total}</span>
            </div>
            <button
              onClick={handleCheckout}
              className="w-full bg-[#fbbf24] text-[#1e3a8a] py-3 rounded-lg font-medium text-lg"
            >
              Proceed to Book
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default CartPage;