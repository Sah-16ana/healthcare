import { useState } from 'react';
import { useParams } from 'react-router-dom';

function TrackingPage() {
  const { appointmentId } = useParams();
  const [status] = useState([
    { 
      step: 1,
      label: 'Appointment Confirmed',
      date: 'Wed, 16th Mar',
      time: '10:30 AM',
      completed: true,
      description: 'Your appointment has been successfully booked'
    },
    {
      step: 2,
      label: 'Technician Assigned',
      date: 'Wed, 16th Mar',
      time: '11:00 AM',
      completed: true,
      description: 'Lab technician John has been assigned to your appointment'
    },
    {
      step: 3,
      label: 'Technician On the Way',
      date: 'Wed, 16th Mar',
      time: '11:45 AM',
      completed: true,
      description: 'Our technician is en route to your location'
    },
    {
      step: 4,
      label: 'Sample Collection',
      date: 'Wed, 16th Mar',
      time: '12:15 PM',
      completed: false,
      description: 'Waiting for sample collection'
    },
    {
      step: 5,
      label: 'Sample Processing',
      date: 'Wed, 17th Mar',
      time: '09:00 AM',
      completed: false,
      description: 'Your sample will be processed in our lab'
    },
    {
      step: 6,
      label: 'Report Generation',
      date: 'Wed, 17th Mar',
      time: '02:00 PM',
      completed: false,
      description: 'Your test report will be generated'
    }
  ]);

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-[#1e3a8a]">Track Appointment</h1>
        <span className="bg-[#fbbf24] text-[#1e3a8a] px-4 py-1 rounded-full text-sm font-medium">
          ID: {appointmentId}
        </span>
      </div>
      
      <div className="space-y-8">
        {status.map((step, index) => (
          <div key={index} className="flex items-start gap-4">
            <div className="flex flex-col items-center">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  step.completed
                    ? 'bg-[#1e3a8a] text-white'
                    : 'bg-gray-200 text-gray-500'
                }`}
              >
                {step.completed ? '✓' : step.step}
              </div>
              {index < status.length - 1 && (
                <div
                  className={`w-0.5 h-24 ${
                    step.completed ? 'bg-[#1e3a8a]' : 'bg-gray-200'
                  }`}
                />
              )}
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h2
                  className={`font-semibold ${
                    step.completed ? 'text-[#1e3a8a]' : 'text-gray-500'
                  }`}
                >
                  {step.label}
                </h2>
                <div className="text-right">
                  <p className="text-sm text-gray-500">{step.date}</p>
                  <p className="text-sm text-gray-500">{step.time}</p>
                </div>
              </div>
              <p className={`mt-1 text-sm ${step.completed ? 'text-gray-600' : 'text-gray-400'}`}>
                {step.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default TrackingPage;