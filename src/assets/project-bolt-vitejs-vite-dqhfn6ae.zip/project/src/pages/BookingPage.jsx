import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

function BookingPage() {
  const { labId, testId } = useParams();
  const navigate = useNavigate();
  const [bookingType, setBookingType] = useState('home');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Mock appointment creation
    const appointmentId = Math.floor(Math.random() * 1000);
    navigate(`/payment/${appointmentId}`);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h1 className="text-2xl font-bold text-[#1e3a8a] mb-6">Book Appointment</h1>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <h2 className="text-lg font-semibold text-[#1e3a8a] mb-3">Select Sample Collection Type</h2>
          <div className="flex gap-4">
            <button
              type="button"
              className={`flex-1 p-4 rounded-lg border-2 ${
                bookingType === 'home'
                  ? 'border-[#1e3a8a] bg-[#1e3a8a] text-white'
                  : 'border-gray-200 text-gray-600'
              }`}
              onClick={() => setBookingType('home')}
            >
              Home Sample Collection
            </button>
            <button
              type="button"
              className={`flex-1 p-4 rounded-lg border-2 ${
                bookingType === 'lab'
                  ? 'border-[#1e3a8a] bg-[#1e3a8a] text-white'
                  : 'border-gray-200 text-gray-600'
              }`}
              onClick={() => setBookingType('lab')}
            >
              Visit Lab
            </button>
          </div>
        </div>

        <div>
          <h2 className="text-lg font-semibold text-[#1e3a8a] mb-3">Select Date</h2>
          <input
            type="date"
            className="w-full p-3 border-2 border-gray-200 rounded-lg"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            required
          />
        </div>

        <div>
          <h2 className="text-lg font-semibold text-[#1e3a8a] mb-3">Select Time Slot</h2>
          <select
            className="w-full p-3 border-2 border-gray-200 rounded-lg"
            value={selectedTime}
            onChange={(e) => setSelectedTime(e.target.value)}
            required
          >
            <option value="">Select a time slot</option>
            <option value="09:00">09:00 AM</option>
            <option value="10:00">10:00 AM</option>
            <option value="11:00">11:00 AM</option>
            <option value="12:00">12:00 PM</option>
          </select>
        </div>

        <button
          type="submit"
          className="w-full bg-[#fbbf24] text-[#1e3a8a] py-3 rounded-lg font-medium text-lg"
        >
          Proceed to Payment
        </button>
      </form>
    </div>
  );
}

export default BookingPage;