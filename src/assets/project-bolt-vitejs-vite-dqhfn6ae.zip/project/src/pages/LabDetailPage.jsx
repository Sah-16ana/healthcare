import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

function LabDetailPage() {
  const { labId, testId } = useParams();
  const navigate = useNavigate();
  const [lab] = useState({
    id: parseInt(labId),
    name: 'HealthCare Labs',
    address: '123, Healthcare Building, Andheri East, Mumbai - 400069',
    rating: 4.5,
    price: 599,
    timings: '7:00 AM - 9:00 PM',
    facilities: ['Home Sample Collection', 'NABL Accredited', 'Online Reports']
  });

  const handleBookAppointment = () => {
    navigate(`/booking/${labId}/${testId}`);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h1 className="text-2xl font-bold text-[#1e3a8a] mb-4">{lab.name}</h1>
      <div className="space-y-4">
        <div className="flex items-center">
          <span className="text-[#fbbf24]">★</span>
          <span className="ml-1 text-gray-600">{lab.rating}</span>
        </div>
        <div className="bg-gray-50 p-4 rounded-lg">
          <h2 className="font-semibold text-[#1e3a8a] mb-2">Address</h2>
          <p className="text-gray-600">{lab.address}</p>
        </div>
        <div className="bg-gray-50 p-4 rounded-lg">
          <h2 className="font-semibold text-[#1e3a8a] mb-2">Timings</h2>
          <p className="text-gray-600">{lab.timings}</p>
        </div>
        <div className="bg-gray-50 p-4 rounded-lg">
          <h2 className="font-semibold text-[#1e3a8a] mb-2">Facilities</h2>
          <ul className="list-disc list-inside text-gray-600">
            {lab.facilities.map((facility, index) => (
              <li key={index}>{facility}</li>
            ))}
          </ul>
        </div>
        <div className="flex items-center justify-between mt-6">
          <span className="text-2xl font-bold text-[#1e3a8a]">₹{lab.price}</span>
          <button
            onClick={handleBookAppointment}
            className="bg-[#fbbf24] text-[#1e3a8a] px-6 py-2 rounded-lg font-medium"
          >
            Book Appointment
          </button>
        </div>
      </div>
    </div>
  );
}

export default LabDetailPage;