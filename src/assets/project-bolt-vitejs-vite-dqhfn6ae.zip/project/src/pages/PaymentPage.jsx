import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

function PaymentPage() {
  const { appointmentId } = useParams();
  const navigate = useNavigate();
  const [paymentMethod, setPaymentMethod] = useState('');
  const [upiId, setUpiId] = useState('');
  const [cardDetails, setCardDetails] = useState({
    number: '',
    name: '',
    expiry: '',
    cvv: ''
  });

  const handlePayment = (e) => {
    e.preventDefault();
    navigate(`/success/${appointmentId}`);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h1 className="text-2xl font-bold text-[#1e3a8a] mb-6">Payment</h1>
      <div className="space-y-6">
        <div className="bg-gray-50 p-4 rounded-lg">
          <h2 className="font-semibold text-[#1e3a8a] mb-2">Amount to Pay</h2>
          <p className="text-2xl font-bold text-[#1e3a8a]">₹599</p>
        </div>

        <form onSubmit={handlePayment} className="space-y-6">
          <div>
            <h2 className="text-lg font-semibold text-[#1e3a8a] mb-3">Select Payment Method</h2>
            <div className="space-y-3">
              {['UPI', 'Card'].map((method) => (
                <label
                  key={method}
                  className={`block p-4 rounded-lg border-2 cursor-pointer ${
                    paymentMethod === method
                      ? 'border-[#1e3a8a] bg-[#1e3a8a] text-white'
                      : 'border-gray-200 text-gray-600'
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    value={method}
                    checked={paymentMethod === method}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="hidden"
                  />
                  {method}
                </label>
              ))}
            </div>
          </div>

          {paymentMethod === 'UPI' && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  UPI ID
                </label>
                <input
                  type="text"
                  placeholder="username@upi"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-[#1e3a8a] focus:outline-none"
                  required
                />
              </div>
            </div>
          )}

          {paymentMethod === 'Card' && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Card Number
                </label>
                <input
                  type="text"
                  placeholder="1234 5678 9012 3456"
                  value={cardDetails.number}
                  onChange={(e) => setCardDetails({...cardDetails, number: e.target.value})}
                  className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-[#1e3a8a] focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Cardholder Name
                </label>
                <input
                  type="text"
                  placeholder="John Doe"
                  value={cardDetails.name}
                  onChange={(e) => setCardDetails({...cardDetails, name: e.target.value})}
                  className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-[#1e3a8a] focus:outline-none"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Expiry Date
                  </label>
                  <input
                    type="text"
                    placeholder="MM/YY"
                    value={cardDetails.expiry}
                    onChange={(e) => setCardDetails({...cardDetails, expiry: e.target.value})}
                    className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-[#1e3a8a] focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    CVV
                  </label>
                  <input
                    type="password"
                    placeholder="123"
                    maxLength="3"
                    value={cardDetails.cvv}
                    onChange={(e) => setCardDetails({...cardDetails, cvv: e.target.value})}
                    className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-[#1e3a8a] focus:outline-none"
                    required
                  />
                </div>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={!paymentMethod}
            className={`w-full py-3 rounded-lg font-medium text-lg ${
              paymentMethod
                ? 'bg-[#fbbf24] text-[#1e3a8a]'
                : 'bg-gray-200 text-gray-500 cursor-not-allowed'
            }`}
          >
            Pay Now
          </button>
        </form>
      </div>
    </div>
  );
}

export default PaymentPage;