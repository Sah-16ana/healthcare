import { useState } from 'react';
import { Link } from 'react-router-dom';

function HomePage() {
  const [activeTab, setActiveTab] = useState('tests');

  const tests = [
    { id: 1, name: 'Complete Blood Count', price: 599, description: 'Includes 25 tests' },
    { id: 2, name: 'Diabetes Screening', price: 899, description: 'Includes 15 tests' },
    { id: 3, name: 'Thyroid Profile', price: 799, description: 'Includes 3 tests' },
  ];

  const scans = [
    { id: 1, name: 'MRI Brain', price: 4999, description: 'Full brain scan' },
    { id: 2, name: 'CT Scan Chest', price: 3999, description: 'Detailed chest imaging' },
    { id: 3, name: 'Ultrasound Abdomen', price: 1999, description: 'Complete abdomen scan' },
  ];

  const packages = [
    {
      id: 1,
      name: 'Full Body Checkup',
      price: 2999,
      description: 'Comprehensive health screening',
      tests: ['Complete Blood Count', 'Liver Function', 'Kidney Function', 'Lipid Profile'],
      savings: '30%'
    },
    {
      id: 2,
      name: 'Diabetes Care Package',
      price: 1999,
      description: 'Complete diabetes screening',
      tests: ['HbA1c', 'Blood Sugar Fasting', 'Blood Sugar PP', 'Kidney Function'],
      savings: '25%'
    }
  ];

  return (
    <div className="space-y-8">
      <div className="flex gap-4 border-b">
        <button
          className={`px-6 py-3 font-medium ${
            activeTab === 'tests'
              ? 'text-[#1e3a8a] border-b-2 border-[#1e3a8a]'
              : 'text-gray-500'
          }`}
          onClick={() => setActiveTab('tests')}
        >
          Tests
        </button>
        <button
          className={`px-6 py-3 font-medium ${
            activeTab === 'scans'
              ? 'text-[#1e3a8a] border-b-2 border-[#1e3a8a]'
              : 'text-gray-500'
          }`}
          onClick={() => setActiveTab('scans')}
        >
          Scans
        </button>
      </div>

      <div className="space-y-8">
        {activeTab === 'tests' && (
          <>
            <div>
              <h2 className="text-2xl font-bold text-[#1e3a8a] mb-4">Health Packages</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {packages.map((pkg) => (
                  <div
                    key={pkg.id}
                    className="bg-white rounded-lg shadow-md p-6 border-2 border-[#1e3a8a]"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="text-xl font-semibold text-[#1e3a8a]">{pkg.name}</h3>
                      <span className="bg-[#fbbf24] text-[#1e3a8a] px-3 py-1 rounded-full text-sm font-medium">
                        Save {pkg.savings}
                      </span>
                    </div>
                    <p className="text-gray-600 mb-4">{pkg.description}</p>
                    <ul className="space-y-2 mb-4">
                      {pkg.tests.map((test, index) => (
                        <li key={index} className="flex items-center text-gray-600">
                          <span className="mr-2">✓</span>
                          {test}
                        </li>
                      ))}
                    </ul>
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold text-[#1e3a8a]">₹{pkg.price}</span>
                      <Link
                        to={`/test/${pkg.id}`}
                        className="bg-[#fbbf24] text-[#1e3a8a] px-6 py-2 rounded-lg font-medium"
                      >
                        View Details
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-[#1e3a8a] mb-4">Individual Tests</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {tests.map((test) => (
                  <Link
                    key={test.id}
                    to={`/test/${test.id}`}
                    className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
                  >
                    <h3 className="text-lg font-semibold text-[#1e3a8a]">{test.name}</h3>
                    <p className="text-gray-600 mt-2">{test.description}</p>
                    <div className="mt-4 flex items-center justify-between">
                      <span className="text-2xl font-bold text-[#1e3a8a]">₹{test.price}</span>
                      <button className="bg-[#fbbf24] text-[#1e3a8a] px-4 py-2 rounded-lg font-medium">
                        View Details
                      </button>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </>
        )}

        {activeTab === 'scans' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {scans.map((scan) => (
              <Link
                key={scan.id}
                to={`/test/${scan.id}`}
                className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
              >
                <h3 className="text-lg font-semibold text-[#1e3a8a]">{scan.name}</h3>
                <p className="text-gray-600 mt-2">{scan.description}</p>
                <div className="mt-4 flex items-center justify-between">
                  <span className="text-2xl font-bold text-[#1e3a8a]">₹{scan.price}</span>
                  <button className="bg-[#fbbf24] text-[#1e3a8a] px-4 py-2 rounded-lg font-medium">
                    View Details
                  </button>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default HomePage;