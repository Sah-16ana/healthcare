import { useParams, Link } from 'react-router-dom';

function SuccessPage() {
  const { appointmentId } = useParams();

  return (
    <div className="bg-white rounded-lg shadow-md p-6 text-center">
      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
        <span className="text-2xl">✓</span>
      </div>
      <h1 className="text-2xl font-bold text-[#1e3a8a] mb-4">Booking Successful!</h1>
      <p className="text-gray-600 mb-6">
        Your appointment has been confirmed. Booking ID: {appointmentId}
      </p>
      <div className="space-y-4">
        <Link
          to={`/tracking/${appointmentId}`}
          className="block w-full bg-[#fbbf24] text-[#1e3a8a] py-3 rounded-lg font-medium"
        >
          Track Appointment
        </Link>
        <Link
          to="/"
          className="block w-full bg-white border-2 border-[#1e3a8a] text-[#1e3a8a] py-3 rounded-lg font-medium"
        >
          Back to Home
        </Link>
      </div>
    </div>
  );
}

export default SuccessPage;