import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';

function TestDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { cart, setCart } = useCart();
  const [test] = useState({
    id: parseInt(id),
    name: 'Complete Blood Count',
    price: 599,
    description: 'Includes 25 tests',
    details: 'A complete blood count (CBC) is a blood test used to evaluate your overall health and screen for various disorders.',
    requirements: 'Fasting for 8-12 hours required',
    reportTime: '24 hours'
  });

  const handleAddToCart = () => {
    setCart([...cart, test]);
  };

  const handleBookNow = () => {
    navigate(`/labs/${id}`);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h1 className="text-2xl font-bold text-[#1e3a8a] mb-4">{test.name}</h1>
      <div className="space-y-4">
        <p className="text-gray-600">{test.details}</p>
        <div className="bg-gray-50 p-4 rounded-lg">
          <h2 className="font-semibold text-[#1e3a8a] mb-2">Test Requirements</h2>
          <p className="text-gray-600">{test.requirements}</p>
        </div>
        <div className="bg-gray-50 p-4 rounded-lg">
          <h2 className="font-semibold text-[#1e3a8a] mb-2">Report Time</h2>
          <p className="text-gray-600">{test.reportTime}</p>
        </div>
        <div className="flex items-center justify-between mt-6">
          <span className="text-2xl font-bold text-[#1e3a8a]">₹{test.price}</span>
          <div className="space-x-4">
            <button
              onClick={handleAddToCart}
              className="bg-white border-2 border-[#1e3a8a] text-[#1e3a8a] px-4 py-2 rounded-lg font-medium"
            >
              Add to Cart
            </button>
            <button
              onClick={handleBookNow}
              className="bg-[#fbbf24] text-[#1e3a8a] px-4 py-2 rounded-lg font-medium"
            >
              Book Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TestDetailPage;