import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';

function LabListPage() {
  const { testId } = useParams();
  const [labs] = useState([
    {
      id: 1,
      name: 'HealthCare Labs',
      location: 'Andheri East',
      rating: 4.5,
      price: 599,
      distance: '2.5 km'
    },
    {
      id: 2,
      name: 'City Diagnostics',
      location: 'Bandra West',
      rating: 4.8,
      price: 649,
      distance: '3.8 km'
    },
    {
      id: 3,
      name: 'Metro Labs',
      location: 'Kurla West',
      rating: 4.2,
      price: 579,
      distance: '4.2 km'
    }
  ]);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-[#1e3a8a]">Available Labs</h1>
      <div className="space-y-4">
        {labs.map(lab => (
          <Link
            key={lab.id}
            to={`/lab/${lab.id}/${testId}`}
            className="block bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
          >
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-lg font-semibold text-[#1e3a8a]">{lab.name}</h2>
                <p className="text-gray-600 mt-1">{lab.location}</p>
                <div className="flex items-center mt-2">
                  <span className="text-[#fbbf24]">★</span>
                  <span className="ml-1 text-gray-600">{lab.rating}</span>
                  <span className="mx-2">•</span>
                  <span className="text-gray-600">{lab.distance}</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-2xl font-bold text-[#1e3a8a]">₹{lab.price}</span>
                <button className="block mt-2 bg-[#fbbf24] text-[#1e3a8a] px-4 py-2 rounded-lg font-medium">
                  Select Lab
                </button>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default LabListPage;