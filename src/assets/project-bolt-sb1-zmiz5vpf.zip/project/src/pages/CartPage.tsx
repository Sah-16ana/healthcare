import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, ArrowLeft, ChevronRight, ShoppingCart, Plus } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { mockTests } from '../data/mockData';

const CartPage = () => {
  const { cart, removeFromCart, clearCart, getTotalPrice } = useCart();
  const navigate = useNavigate();
  
  // If user has a single test in cart, navigate to labs page
  const handleProceed = () => {
    if (cart.length === 1) {
      navigate(`/labs/${cart[0].id}`);
    } else {
      // In a real app, this would go to a multi-test booking flow
      // For demo, we'll just navigate to labs page for the first test
      if (cart.length > 0) {
        navigate(`/labs/${cart[0].id}`);
      }
    }
  };

  // Get recommended tests based on cart items
  const getRecommendedTests = () => {
    const cartIds = cart.map(item => item.id);
    return mockTests
      .filter(test => !cartIds.includes(test.id))
      .slice(0, 3);
  };

  const recommendedTests = getRecommendedTests();

  return (
    <div>
      {/* Back Button */}
      <Link to="/" className="flex items-center text-gray-600 mb-6 hover:text-blue-600">
        <ArrowLeft size={20} className="mr-1" />
        <span>Continue Shopping</span>
      </Link>
      
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Your Cart</h1>
      
      {cart.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <div className="mx-auto bg-gray-100 rounded-full p-4 w-20 h-20 flex items-center justify-center mb-4">
            <ShoppingCart size={36} className="text-gray-500" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Your cart is empty</h2>
          <p className="text-gray-600 mb-6">
            You haven't added any tests or packages to your cart yet.
          </p>
          <Link 
            to="/"
            className="inline-flex items-center bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors"
          >
            Browse Tests
            <ChevronRight size={18} className="ml-1" />
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
              <div className="p-6 border-b border-gray-200">
                <div className="flex justify-between items-center">
                  <h2 className="text-lg font-semibold text-gray-900">
                    Cart Items ({cart.length})
                  </h2>
                  <button 
                    onClick={clearCart}
                    className="text-sm text-red-600 hover:text-red-800"
                  >
                    Clear All
                  </button>
                </div>
              </div>
              
              {cart.map(item => (
                <div key={item.id} className="p-6 border-b border-gray-200 last:border-b-0">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium text-gray-900 mb-1">{item.name}</h3>
                      <div className="flex items-center text-sm text-gray-500 mb-2">
                        <span className="mr-3">Code: {item.code}</span>
                        <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                          {item.category}
                        </span>
                      </div>
                      <p className="text-gray-600 text-sm mb-2">{item.description}</p>
                      {item.requirements && (
                        <p className="text-gray-600 text-xs">{item.requirements}</p>
                      )}
                    </div>
                    
                    <div className="flex flex-col items-end">
                      <div className="flex items-baseline mb-1">
                        <span className="text-lg font-bold text-gray-900">₹{item.price}</span>
                        {item.originalPrice && (
                          <span className="text-sm text-gray-500 line-through ml-2">
                            ₹{item.originalPrice}
                          </span>
                        )}
                      </div>
                      
                      <button 
                        onClick={() => removeFromCart(item.id)}
                        className="flex items-center text-red-600 hover:text-red-800 text-sm mt-2"
                      >
                        <Trash2 size={16} className="mr-1" />
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Recommended Tests */}
            {recommendedTests.length > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">
                  Recommended Tests
                </h2>
                
                <div className="space-y-4">
                  {recommendedTests.map(test => (
                    <div key={test.id} className="flex justify-between items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                      <div>
                        <h3 className="font-medium text-gray-800">{test.name}</h3>
                        <p className="text-sm text-gray-600">{test.category}</p>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <span className="text-gray-900 font-medium">₹{test.price}</span>
                        <Link 
                          to={`/test/${test.id}`}
                          className="text-blue-600 hover:text-blue-800 text-sm border border-blue-600 rounded-md px-3 py-1"
                        >
                          View
                        </Link>
                        <button
                          onClick={() => navigate(`/test/${test.id}`)}
                          className="bg-blue-600 text-white hover:bg-blue-700 text-sm rounded-md px-3 py-1 flex items-center"
                        >
                          <Plus size={14} className="mr-1" />
                          Add
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-20">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">
                Order Summary
              </h2>
              
              <div className="border-b border-gray-200 pb-4 mb-4">
                <div className="space-y-2">
                  {cart.map(item => (
                    <div key={item.id} className="flex justify-between text-gray-600">
                      <span className="line-clamp-1">{item.name}</span>
                      <span>₹{item.price}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="pb-4 mb-4">
                <div className="flex justify-between mb-2 text-gray-600">
                  <span>Subtotal</span>
                  <span>₹{getTotalPrice()}</span>
                </div>
                
                <div className="flex justify-between text-lg font-bold mt-4">
                  <span className="text-gray-800">Total</span>
                  <span className="text-blue-600">₹{getTotalPrice()}</span>
                </div>
              </div>
              
              <button
                onClick={handleProceed}
                className="w-full bg-blue-600 text-white py-3 rounded-md text-center font-medium hover:bg-blue-700 transition-colors"
              >
                Proceed to Book
              </button>
              
              <p className="text-xs text-gray-500 mt-4 text-center">
                By proceeding, you agree to our Terms of Service and Privacy Policy
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CartPage;