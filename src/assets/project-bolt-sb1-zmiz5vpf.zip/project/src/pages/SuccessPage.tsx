import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { CheckCircle, Calendar, ArrowRight, Download, Share2, Loader2 } from 'lucide-react';
import { mockApi } from '../data/mockData';
import { Appointment } from '../types';

const SuccessPage = () => {
  const { appointmentId } = useParams<{ appointmentId: string }>();
  const [appointment, setAppointment] = useState<Appointment | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchAppointment = async () => {
      if (!appointmentId) return;
      
      setLoading(true);
      try {
        const data = await mockApi.getAppointmentById(appointmentId);
        if (data) {
          setAppointment(data);
        }
      } catch (error) {
        console.error('Error fetching appointment:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAppointment();
  }, [appointmentId]);

  const handleViewAppointment = () => {
    if (appointmentId) {
      navigate(`/tracking/${appointmentId}`);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 size={40} className="animate-spin text-blue-600" />
      </div>
    );
  }

  if (!appointment) {
    return (
      <div className="text-center py-12">
        <p className="text-lg text-gray-600">Appointment not found</p>
        <Link to="/" className="text-blue-600 hover:underline mt-4 inline-block">
          Go back to home
        </Link>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center max-w-2xl mx-auto">
      <div className="w-full bg-white rounded-lg shadow-md p-8 text-center mb-6">
        <div className="mb-6">
          <div className="mx-auto bg-green-100 rounded-full p-4 w-20 h-20 flex items-center justify-center mb-4">
            <CheckCircle size={48} className="text-green-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Appointment Confirmed!</h1>
          <p className="text-gray-600">
            Your appointment has been successfully booked and payment received.
          </p>
        </div>
        
        <div className="border-t border-b border-gray-200 py-6 mb-6">
          <div className="flex flex-col items-center space-y-2">
            <Calendar size={24} className="text-blue-600 mb-2" />
            <h2 className="text-lg font-semibold text-gray-800">Appointment Details</h2>
            <p className="text-gray-600">
              {new Date(appointment.date).toLocaleDateString('en-US', {
                weekday: 'long',
                day: 'numeric',
                month: 'long',
                year: 'numeric'
              })}
              {' at '}
              {appointment.time}
            </p>
            <p className="text-gray-600 font-medium">
              {appointment.type === 'home' ? 'Home Sample Collection' : 'Lab Visit'}
            </p>
          </div>
        </div>
        
        <div className="space-y-4 mb-8">
          <p className="text-gray-600">
            An email confirmation has been sent to <span className="font-medium">{appointment.patientEmail}</span>
          </p>
          <p className="text-gray-600">
            Booking ID: <span className="font-medium">{appointment.id}</span>
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3 justify-center">
          <button 
            onClick={handleViewAppointment}
            className="flex items-center justify-center bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors"
          >
            Track Appointment
            <ArrowRight size={18} className="ml-2" />
          </button>
          
          <button className="flex items-center justify-center border border-gray-300 text-gray-700 px-6 py-3 rounded-md hover:bg-gray-50 transition-colors">
            <Download size={18} className="mr-2" />
            Download Receipt
          </button>
        </div>
      </div>
      
      <div className="w-full bg-blue-50 border border-blue-100 rounded-lg p-6 flex flex-col sm:flex-row items-center justify-between">
        <div className="text-center sm:text-left mb-4 sm:mb-0">
          <h3 className="font-medium text-gray-800 mb-1">Share with family or friends</h3>
          <p className="text-sm text-gray-600">Let them know about your appointment</p>
        </div>
        
        <button className="flex items-center bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 transition-colors">
          <Share2 size={18} className="mr-2" />
          Share Details
        </button>
      </div>
      
      <div className="mt-8">
        <Link to="/" className="text-blue-600 hover:underline">
          Return to Home
        </Link>
      </div>
    </div>
  );
};

export default SuccessPage;