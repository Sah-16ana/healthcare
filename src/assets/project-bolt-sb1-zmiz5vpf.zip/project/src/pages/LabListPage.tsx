import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, Filter, Loader2 } from 'lucide-react';
import { mockApi } from '../data/mockData';
import { Test, Lab } from '../types';
import LabCard from '../components/LabCard';

const LabListPage = () => {
  const { testId } = useParams<{ testId: string }>();
  const [test, setTest] = useState<Test | null>(null);
  const [labs, setLabs] = useState<Lab[]>([]);
  const [loading, setLoading] = useState(true);
  const [locationFilter, setLocationFilter] = useState<string>('');
  const [homeCollectionFilter, setHomeCollectionFilter] = useState<boolean | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      if (!testId) return;
      
      setLoading(true);
      try {
        const [testData, labsData] = await Promise.all([
          mockApi.getTestById(testId),
          mockApi.getLabsForTest(testId)
        ]);
        
        if (testData) {
          setTest(testData);
        }
        
        setLabs(labsData);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [testId]);

  // Apply filters
  const filteredLabs = labs.filter(lab => {
    // Filter by location
    if (locationFilter && !lab.area.toLowerCase().includes(locationFilter.toLowerCase()) && 
        !lab.city.toLowerCase().includes(locationFilter.toLowerCase())) {
      return false;
    }
    
    // Filter by home collection
    if (homeCollectionFilter !== null && lab.homeCollection !== homeCollectionFilter) {
      return false;
    }
    
    return true;
  });

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 size={40} className="animate-spin text-blue-600" />
      </div>
    );
  }

  if (!test) {
    return (
      <div className="text-center py-12">
        <p className="text-lg text-gray-600">Test not found</p>
        <Link to="/" className="text-blue-600 hover:underline mt-4 inline-block">
          Go back to home
        </Link>
      </div>
    );
  }

  return (
    <div>
      {/* Back Button */}
      <Link to={`/test/${testId}`} className="flex items-center text-gray-600 mb-6 hover:text-blue-600">
        <ArrowLeft size={20} className="mr-1" />
        <span>Back to Test Details</span>
      </Link>
      
      {/* Test Info */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h1 className="text-xl font-bold text-gray-900 mb-2">
          Labs for {test.name}
        </h1>
        <p className="text-gray-600 mb-2">
          Select from available labs to continue with your booking
        </p>
        <div className="flex flex-wrap items-center text-sm text-gray-500">
          <span className="mr-3">Code: {test.code}</span>
          <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded mr-3">
            {test.category}
          </span>
          <span>Price: ₹{test.price}</span>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <MapPin size={16} className="absolute left-3 top-2.5 text-gray-500" />
            <input
              type="text"
              placeholder="Filter by location"
              value={locationFilter}
              onChange={(e) => setLocationFilter(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div className="flex items-center space-x-6">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={homeCollectionFilter === true}
                onChange={() => {
                  setHomeCollectionFilter(homeCollectionFilter === true ? null : true);
                }}
                className="h-4 w-4 text-blue-600 rounded focus:ring-blue-500"
              />
              <span className="text-gray-700">Home Collection</span>
            </label>
            
            <button
              onClick={() => {
                setLocationFilter('');
                setHomeCollectionFilter(null);
              }}
              className="text-blue-600 hover:text-blue-800 text-sm"
            >
              Clear Filters
            </button>
          </div>
        </div>
      </div>
      
      {/* Labs List */}
      <div className="space-y-6">
        {filteredLabs.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <p className="text-gray-600">No labs found matching your filters.</p>
            {(locationFilter || homeCollectionFilter !== null) && (
              <button
                onClick={() => {
                  setLocationFilter('');
                  setHomeCollectionFilter(null);
                }}
                className="text-blue-600 hover:underline mt-2"
              >
                Clear filters
              </button>
            )}
          </div>
        ) : (
          filteredLabs.map(lab => (
            <LabCard 
              key={lab.id} 
              lab={lab} 
              testId={testId || ''} 
            />
          ))
        )}
      </div>
    </div>
  );
};

export default LabListPage;