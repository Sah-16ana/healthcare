import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, CreditCard, Banknote, Wallet, Check, ChevronRight, Loader2 } from 'lucide-react';
import { mockApi } from '../data/mockData';
import { Appointment } from '../types';

const PaymentPage = () => {
  const { appointmentId } = useParams<{ appointmentId: string }>();
  const [appointment, setAppointment] = useState<Appointment | null>(null);
  const [loading, setLoading] = useState(true);
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'upi' | 'cod'>('card');
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [upiId, setUpiId] = useState('');
  const [processingPayment, setProcessingPayment] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchAppointment = async () => {
      if (!appointmentId) return;
      
      setLoading(true);
      try {
        const data = await mockApi.getAppointmentById(appointmentId);
        if (data) {
          setAppointment(data);
        }
      } catch (error) {
        console.error('Error fetching appointment:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAppointment();
  }, [appointmentId]);

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!appointment || !appointmentId) return;
    
    setProcessingPayment(true);
    
    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Process payment
      await mockApi.processPayment(appointmentId);
      
      // Navigate to success page
      navigate(`/success/${appointmentId}`);
    } catch (error) {
      console.error('Error processing payment:', error);
      setProcessingPayment(false);
    }
  };

  const isFormValid = () => {
    if (paymentMethod === 'card') {
      return cardNumber && cardName && cardExpiry && cardCvv;
    } else if (paymentMethod === 'upi') {
      return upiId;
    }
    return true; // COD doesn't need validation
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 size={40} className="animate-spin text-blue-600" />
      </div>
    );
  }

  if (!appointment) {
    return (
      <div className="text-center py-12">
        <p className="text-lg text-gray-600">Appointment not found</p>
        <Link to="/" className="text-blue-600 hover:underline mt-4 inline-block">
          Go back to home
        </Link>
      </div>
    );
  }

  return (
    <div className="mb-16">
      {/* Back Button */}
      <Link 
        to={`/booking/${appointment.labId}/${appointment.testId}`} 
        className="flex items-center text-gray-600 mb-6 hover:text-blue-600"
      >
        <ArrowLeft size={20} className="mr-1" />
        <span>Back to Booking</span>
      </Link>
      
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Payment</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Payment Form */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Payment Methods
            </h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
              <button
                type="button"
                className={`flex items-center p-4 border rounded-lg ${
                  paymentMethod === 'card' 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-300 hover:border-blue-300 hover:bg-blue-50'
                } transition-colors`}
                onClick={() => setPaymentMethod('card')}
              >
                <CreditCard size={24} className={`mr-2 ${paymentMethod === 'card' ? 'text-blue-600' : 'text-gray-500'}`} />
                <span className={`font-medium ${paymentMethod === 'card' ? 'text-blue-600' : 'text-gray-700'}`}>
                  Card
                </span>
              </button>
              
              <button
                type="button"
                className={`flex items-center p-4 border rounded-lg ${
                  paymentMethod === 'upi' 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-300 hover:border-blue-300 hover:bg-blue-50'
                } transition-colors`}
                onClick={() => setPaymentMethod('upi')}
              >
                <Wallet size={24} className={`mr-2 ${paymentMethod === 'upi' ? 'text-blue-600' : 'text-gray-500'}`} />
                <span className={`font-medium ${paymentMethod === 'upi' ? 'text-blue-600' : 'text-gray-700'}`}>
                  UPI
                </span>
              </button>
              
              <button
                type="button"
                className={`flex items-center p-4 border rounded-lg ${
                  paymentMethod === 'cod' 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-300 hover:border-blue-300 hover:bg-blue-50'
                } transition-colors`}
                onClick={() => setPaymentMethod('cod')}
              >
                <Banknote size={24} className={`mr-2 ${paymentMethod === 'cod' ? 'text-blue-600' : 'text-gray-500'}`} />
                <span className={`font-medium ${paymentMethod === 'cod' ? 'text-blue-600' : 'text-gray-700'}`}>
                  Cash on Delivery
                </span>
              </button>
            </div>
            
            <form onSubmit={handlePayment}>
              {/* Card Payment Form */}
              {paymentMethod === 'card' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Card Number
                    </label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="1234 5678 9012 3456"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Cardholder Name
                    </label>
                    <input
                      type="text"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="John Doe"
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Expiry Date
                      </label>
                      <input
                        type="text"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="MM/YY"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        CVV
                      </label>
                      <input
                        type="password"
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="123"
                        maxLength={3}
                        required
                      />
                    </div>
                  </div>
                </div>
              )}
              
              {/* UPI Payment Form */}
              {paymentMethod === 'upi' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      UPI ID
                    </label>
                    <input
                      type="text"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="yourname@upi"
                      required
                    />
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-md text-sm text-gray-600">
                    <p>
                      Please make sure your UPI ID is correct. You will receive a payment request on your UPI app.
                    </p>
                  </div>
                </div>
              )}
              
              {/* COD Payment Info */}
              {paymentMethod === 'cod' && (
                <div className="bg-gray-50 p-4 rounded-md text-sm text-gray-600">
                  <p className="mb-2">
                    You will pay in cash at the time of sample collection or at the lab.
                  </p>
                  <p>
                    Please keep the exact amount ready to avoid any inconvenience.
                  </p>
                </div>
              )}
              
              <button
                type="submit"
                disabled={!isFormValid() || processingPayment}
                className={`w-full flex items-center justify-center py-3 px-4 rounded-md text-white mt-6 ${
                  isFormValid() && !processingPayment
                    ? 'bg-blue-600 hover:bg-blue-700'
                    : 'bg-gray-400 cursor-not-allowed'
                } transition-colors`}
              >
                {processingPayment ? (
                  <>
                    <Loader2 size={20} className="animate-spin mr-2" />
                    Processing Payment...
                  </>
                ) : (
                  <>
                    Pay ₹{appointment.amount}
                    <ChevronRight size={18} className="ml-1" />
                  </>
                )}
              </button>
            </form>
          </div>
          
          <div className="bg-yellow-50 border border-yellow-100 rounded-lg p-4 text-sm text-yellow-800">
            <p className="font-medium mb-1">Note:</p>
            <p>
              This is a demo application. No actual payment will be processed.
            </p>
          </div>
        </div>
        
        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6 sticky top-20">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Order Summary
            </h2>
            
            <div className="border-b border-gray-200 pb-4 mb-4">
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Patient:</span>
                <span className="font-medium text-gray-800">{appointment.patientName}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Appointment:</span>
                <span className="font-medium text-gray-800">
                  {new Date(appointment.date).toLocaleDateString('en-US', {
                    weekday: 'short',
                    day: 'numeric',
                    month: 'short'
                  })}
                  {' '}
                  {appointment.time}
                </span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Location:</span>
                <span className="font-medium text-gray-800">
                  {appointment.type === 'home' ? 'Home Collection' : 'Lab Visit'}
                </span>
              </div>
            </div>
            
            <div className="pb-4 mb-4">
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Test Amount:</span>
                <span className="font-medium text-gray-800">₹{appointment.amount}</span>
              </div>
              
              <div className="flex justify-between text-lg font-bold mt-4">
                <span className="text-gray-800">Total:</span>
                <span className="text-blue-600">₹{appointment.amount}</span>
              </div>
            </div>
            
            <div className="flex items-center justify-center bg-green-50 p-3 rounded-md">
              <Check size={18} className="text-green-600 mr-2" />
              <span className="text-sm text-green-800">Secure Payment</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentPage;