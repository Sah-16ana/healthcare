import React, { useState, useEffect } from 'react';
import TabNavigation from '../components/TabNavigation';
import TestCard from '../components/TestCard';
import { mockApi } from '../data/mockData';
import { Test, Package } from '../types';
import { useSearch } from '../context/SearchContext';
import { Loader2 } from 'lucide-react';

const HomePage = () => {
  const [activeTab, setActiveTab] = useState<'tests' | 'scans'>('tests');
  const [tests, setTests] = useState<Test[]>([]);
  const [scans, setScans] = useState<Test[]>([]);
  const [packages, setPackages] = useState<Package[]>([]);
  const [loading, setLoading] = useState(true);
  const { searchResults, searchQuery, isSearching } = useSearch();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [testsData, scansData, packagesData] = await Promise.all([
          mockApi.getTests(),
          mockApi.getScans(),
          mockApi.getPackages()
        ]);
        
        setTests(testsData);
        setScans(scansData);
        setPackages(packagesData);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const renderContent = () => {
    if (searchQuery) {
      if (isSearching) {
        return (
          <div className="flex justify-center items-center py-12">
            <Loader2 size={40} className="animate-spin text-blue-600" />
          </div>
        );
      }
      
      if (searchResults.length === 0) {
        return (
          <div className="text-center py-12">
            <p className="text-lg text-gray-600">No results found for "{searchQuery}"</p>
            <p className="text-gray-500 mt-2">Try different keywords or browse our categories</p>
          </div>
        );
      }
      
      return (
        <div>
          <h2 className="text-xl font-bold text-gray-800 mb-4">Search Results for "{searchQuery}"</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {searchResults.map(item => (
              <TestCard key={item.id} item={item} />
            ))}
          </div>
        </div>
      );
    }

    if (loading) {
      return (
        <div className="flex justify-center items-center py-12">
          <Loader2 size={40} className="animate-spin text-blue-600" />
        </div>
      );
    }

    return (
      <>
        <section className="mb-10">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Popular Health Packages</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {packages.map(pkg => (
              <TestCard key={pkg.id} item={pkg} showPackageDetails={true} />
            ))}
          </div>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-800 mb-4">
            {activeTab === 'tests' ? 'Lab Tests' : 'Diagnostic Scans'}
          </h2>
          <TabNavigation 
            activeTab={activeTab} 
            onTabChange={(tab) => setActiveTab(tab)} 
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeTab === 'tests' 
              ? tests.map(test => <TestCard key={test.id} item={test} />)
              : scans.map(scan => <TestCard key={scan.id} item={scan} />)
            }
          </div>
        </section>
      </>
    );
  };

  return (
    <div>
      {renderContent()}
    </div>
  );
};

export default HomePage;