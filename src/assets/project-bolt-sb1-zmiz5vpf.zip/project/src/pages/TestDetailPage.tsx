import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Clock, Clipboard, Users, ChevronRight, Plus, Check, ArrowLeft } from 'lucide-react';
import { mockApi } from '../data/mockData';
import { Test } from '../types';
import { useCart } from '../context/CartContext';
import { Loader2 } from 'lucide-react';

const TestDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const [test, setTest] = useState<Test | null>(null);
  const [loading, setLoading] = useState(true);
  const { addToCart, isInCart } = useCart();
  const alreadyInCart = id ? isInCart(id) : false;

  useEffect(() => {
    const fetchTest = async () => {
      if (!id) return;
      
      setLoading(true);
      try {
        const testData = await mockApi.getTestById(id);
        if (testData) {
          setTest(testData);
        }
      } catch (error) {
        console.error('Error fetching test details:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTest();
  }, [id]);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 size={40} className="animate-spin text-blue-600" />
      </div>
    );
  }

  if (!test) {
    return (
      <div className="text-center py-12">
        <p className="text-lg text-gray-600">Test not found</p>
        <Link to="/" className="text-blue-600 hover:underline mt-4 inline-block">
          Go back to home
        </Link>
      </div>
    );
  }

  return (
    <div>
      {/* Back Button */}
      <Link to="/" className="flex items-center text-gray-600 mb-6 hover:text-blue-600">
        <ArrowLeft size={20} className="mr-1" />
        <span>Back to Tests</span>
      </Link>
      
      {/* Test Header */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex justify-between items-start flex-wrap">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">{test.name}</h1>
            <div className="flex items-center text-sm text-gray-500 mb-3">
              <span className="mr-3">Code: {test.code}</span>
              <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                {test.category}
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-3 mt-2 sm:mt-0">
            <div className="flex flex-col items-end">
              <div className="flex items-baseline">
                <span className="text-2xl font-bold text-gray-900">₹{test.price}</span>
                {test.originalPrice && (
                  <span className="text-sm text-gray-500 line-through ml-2">
                    ₹{test.originalPrice}
                  </span>
                )}
              </div>
              {test.originalPrice && (
                <span className="text-xs text-green-600">
                  Save ₹{test.originalPrice - test.price}
                </span>
              )}
            </div>
            
            <button
              onClick={() => addToCart(test)}
              disabled={alreadyInCart}
              className={`flex items-center px-4 py-2 rounded-md ${
                alreadyInCart 
                  ? 'bg-gray-200 text-gray-600 cursor-not-allowed' 
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              {alreadyInCart ? (
                <>
                  <Check size={18} className="mr-1.5" />
                  Added to Cart
                </>
              ) : (
                <>
                  <Plus size={18} className="mr-1.5" />
                  Add to Cart
                </>
              )}
            </button>
          </div>
        </div>
        
        <p className="text-gray-700 mt-4">{test.description}</p>
        
        <div className="flex flex-wrap gap-6 mt-6 text-sm">
          <div className="flex items-center text-gray-700">
            <Clock size={18} className="mr-2 text-blue-600" />
            <span>Report: {test.reportTime}</span>
          </div>
          <div className="flex items-center text-gray-700">
            <Clipboard size={18} className="mr-2 text-blue-600" />
            <span>{test.requirements}</span>
          </div>
        </div>
      </div>
      
      {/* Call to Action */}
      <div className="bg-blue-50 border border-blue-100 rounded-lg p-6 mb-6">
        <div className="flex items-start">
          <Users size={24} className="text-blue-600 mr-4 mt-1 flex-shrink-0" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Find the best labs for {test.name}
            </h3>
            <p className="text-gray-700 mb-4">
              Compare prices, check availability, and book appointments at top-rated diagnostic labs near you.
            </p>
            <Link 
              to={`/labs/${test.id}`}
              className="inline-flex items-center bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
            >
              View Available Labs
              <ChevronRight size={18} className="ml-1" />
            </Link>
          </div>
        </div>
      </div>
      
      {/* About the Test */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">About {test.name}</h2>
        <div className="space-y-4">
          <div>
            <h3 className="font-medium text-gray-800 mb-2">What is {test.name}?</h3>
            <p className="text-gray-700">
              {test.description} This test helps doctors diagnose and monitor various health conditions.
            </p>
          </div>
          
          <div>
            <h3 className="font-medium text-gray-800 mb-2">Why is it done?</h3>
            <p className="text-gray-700">
              {test.name} is typically done to screen for, diagnose, or monitor a variety of diseases and conditions.
            </p>
          </div>
          
          <div>
            <h3 className="font-medium text-gray-800 mb-2">Preparation Required</h3>
            <p className="text-gray-700">
              {test.requirements}
            </p>
          </div>
        </div>
      </div>
      
      {/* Proceed Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-white p-4 border-t border-gray-200 shadow-md md:hidden">
        <Link 
          to={`/labs/${test.id}`}
          className="block w-full bg-blue-600 text-white py-3 rounded-md text-center font-medium hover:bg-blue-700"
        >
          View Available Labs
        </Link>
      </div>
    </div>
  );
};

export default TestDetailPage;