import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Printer, Download, Share2, MapPin, Phone, Loader2 } from 'lucide-react';
import { mockApi } from '../data/mockData';
import { Appointment, Lab, Test } from '../types';
import AppointmentTracker from '../components/AppointmentTracker';

const TrackingPage = () => {
  const { appointmentId } = useParams<{ appointmentId: string }>();
  const [appointment, setAppointment] = useState<Appointment | null>(null);
  const [test, setTest] = useState<Test | null>(null);
  const [lab, setLab] = useState<Lab | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!appointmentId) return;
      
      setLoading(true);
      try {
        const appointmentData = await mockApi.getAppointmentById(appointmentId);
        
        if (appointmentData) {
          setAppointment(appointmentData);
          
          // Fetch test and lab details
          const [testData, labData] = await Promise.all([
            mockApi.getTestById(appointmentData.testId),
            mockApi.getLabById(appointmentData.labId)
          ]);
          
          if (testData) {
            setTest(testData);
          }
          
          if (labData) {
            setLab(labData);
          }
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [appointmentId]);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 size={40} className="animate-spin text-blue-600" />
      </div>
    );
  }

  if (!appointment || !test || !lab) {
    return (
      <div className="text-center py-12">
        <p className="text-lg text-gray-600">Appointment not found</p>
        <Link to="/" className="text-blue-600 hover:underline mt-4 inline-block">
          Go back to home
        </Link>
      </div>
    );
  }

  return (
    <div>
      {/* Back Button */}
      <Link to="/" className="flex items-center text-gray-600 mb-6 hover:text-blue-600">
        <ArrowLeft size={20} className="mr-1" />
        <span>Back to Home</span>
      </Link>
      
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Track Your Appointment</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          {/* Appointment Tracker */}
          <AppointmentTracker 
            status={appointment.status} 
            dates={appointment.statusDates} 
          />
          
          {/* Appointment Details */}
          <div className="bg-white rounded-lg shadow-md p-6 mt-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Appointment Details
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium text-gray-800 mb-2">Test Information</h3>
                <ul className="space-y-2 text-gray-600">
                  <li><span className="font-medium">Test Name:</span> {test.name}</li>
                  <li><span className="font-medium">Test Code:</span> {test.code}</li>
                  <li><span className="font-medium">Category:</span> {test.category}</li>
                  <li><span className="font-medium">Report Time:</span> {lab.reportTime}</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-medium text-gray-800 mb-2">Appointment Information</h3>
                <ul className="space-y-2 text-gray-600">
                  <li><span className="font-medium">Date:</span> {new Date(appointment.date).toLocaleDateString('en-US', {
                    weekday: 'short',
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric'
                  })}</li>
                  <li><span className="font-medium">Time:</span> {appointment.time}</li>
                  <li><span className="font-medium">Type:</span> {appointment.type === 'home' ? 'Home Collection' : 'Lab Visit'}</li>
                  <li><span className="font-medium">Payment:</span> {appointment.paymentStatus === 'paid' ? 'Paid' : 'Pending'}</li>
                </ul>
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-200">
              <h3 className="font-medium text-gray-800 mb-2">Patient Information</h3>
              <ul className="space-y-2 text-gray-600">
                <li><span className="font-medium">Name:</span> {appointment.patientName}</li>
                <li><span className="font-medium">Phone:</span> {appointment.patientPhone}</li>
                <li><span className="font-medium">Email:</span> {appointment.patientEmail}</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-1">
          {/* Lab Information */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Lab Information
            </h2>
            
            <div className="mb-4">
              <h3 className="font-medium text-gray-800 mb-2">{lab.name}</h3>
              <div className="flex items-start text-gray-600 mb-2">
                <MapPin size={16} className="mt-1 mr-2 flex-shrink-0" />
                <span>{lab.address}</span>
              </div>
              <div className="flex items-center text-gray-600">
                <Phone size={16} className="mr-2" />
                <a href="tel:+919876543210" className="text-blue-600 hover:underline">
                  +91 98765 43210
                </a>
              </div>
            </div>
            
            <div className="mt-6 pt-4 border-t border-gray-200">
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-600">Amount Paid:</span>
                <span className="font-bold text-gray-900">₹{appointment.amount}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Payment Status:</span>
                <span className="font-medium text-green-600">Paid</span>
              </div>
            </div>
          </div>
          
          {/* Actions */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Actions
            </h2>
            
            <div className="space-y-3">
              <button className="w-full flex items-center justify-center bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
                <Download size={18} className="mr-2" />
                Download Report
              </button>
              
              <button className="w-full flex items-center justify-center border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 transition-colors">
                <Printer size={18} className="mr-2" />
                Print Receipt
              </button>
              
              <button className="w-full flex items-center justify-center border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 transition-colors">
                <Share2 size={18} className="mr-2" />
                Share Details
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrackingPage;