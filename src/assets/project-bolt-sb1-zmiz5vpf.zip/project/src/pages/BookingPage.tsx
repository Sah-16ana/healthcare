import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Home, Building, Calendar, Clock, MapPin, CreditCard, Loader2 } from 'lucide-react';
import { mockApi } from '../data/mockData';
import { Test, Lab } from '../types';

const BookingPage = () => {
  const { labId, testId } = useParams<{ labId: string; testId: string }>();
  const [test, setTest] = useState<Test | null>(null);
  const [lab, setLab] = useState<Lab | null>(null);
  const [loading, setLoading] = useState(true);
  const [locationType, setLocationType] = useState<'home' | 'lab'>('home');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [patientName, setPatientName] = useState<string>('');
  const [patientPhone, setPatientPhone] = useState<string>('');
  const [patientEmail, setPatientEmail] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [bookingInProgress, setBookingInProgress] = useState(false);
  const navigate = useNavigate();

  // Generate available dates (next 7 days)
  const availableDates = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + i);
    return date.toISOString().split('T')[0];
  });

  // Generate available time slots
  const availableTimeSlots = [
    '07:00 AM', '08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM',
    '12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM',
    '05:00 PM', '06:00 PM', '07:00 PM', '08:00 PM'
  ];

  useEffect(() => {
    const fetchData = async () => {
      if (!testId || !labId) return;
      
      setLoading(true);
      try {
        const [testData, labData] = await Promise.all([
          mockApi.getTestById(testId),
          mockApi.getLabById(labId)
        ]);
        
        if (testData) {
          setTest(testData);
        }
        
        if (labData) {
          setLab(labData);
          
          // If home collection is not available, default to lab
          if (!labData.homeCollection) {
            setLocationType('lab');
          }
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [testId, labId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!test || !lab || !selectedDate || !selectedTime || !patientName || !patientPhone || !patientEmail) {
      return;
    }
    
    setBookingInProgress(true);
    
    try {
      const appointmentData = {
        testId,
        labId,
        type: locationType,
        date: selectedDate,
        time: selectedTime,
        address: locationType === 'home' ? address : lab.address,
        amount: lab.price,
        patientName,
        patientPhone,
        patientEmail
      };
      
      const appointment = await mockApi.createAppointment(appointmentData);
      
      // Navigate to payment page with appointment ID
      navigate(`/payment/${appointment.id}`);
    } catch (error) {
      console.error('Error booking appointment:', error);
      setBookingInProgress(false);
    }
  };

  const isFormValid = () => {
    if (!selectedDate || !selectedTime || !patientName || !patientPhone || !patientEmail) {
      return false;
    }
    
    if (locationType === 'home' && !address) {
      return false;
    }
    
    return true;
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 size={40} className="animate-spin text-blue-600" />
      </div>
    );
  }

  if (!test || !lab) {
    return (
      <div className="text-center py-12">
        <p className="text-lg text-gray-600">Information not found</p>
        <Link to="/" className="text-blue-600 hover:underline mt-4 inline-block">
          Go back to home
        </Link>
      </div>
    );
  }

  // Check if test type is scan and home collection is selected
  const isScanWithHomeCollection = test.type === 'scan' && locationType === 'home';

  return (
    <div className="mb-16">
      {/* Back Button */}
      <Link to={`/lab/${labId}/${testId}`} className="flex items-center text-gray-600 mb-6 hover:text-blue-600">
        <ArrowLeft size={20} className="mr-1" />
        <span>Back to Lab Details</span>
      </Link>
      
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Book Appointment</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Booking Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6">
            {/* Sample Collection Location */}
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">
                Sample Collection Location
              </h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <button
                  type="button"
                  className={`flex items-center p-4 border rounded-lg ${
                    locationType === 'home' 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-300 hover:border-blue-300 hover:bg-blue-50'
                  } transition-colors ${
                    (!lab.homeCollection || isScanWithHomeCollection) ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                  onClick={() => {
                    if (lab.homeCollection && !isScanWithHomeCollection) {
                      setLocationType('home');
                    }
                  }}
                  disabled={!lab.homeCollection || isScanWithHomeCollection}
                >
                  <Home size={24} className={`mr-3 ${locationType === 'home' ? 'text-blue-600' : 'text-gray-500'}`} />
                  <div className="text-left">
                    <div className={`font-medium ${locationType === 'home' ? 'text-blue-600' : 'text-gray-700'}`}>
                      Home Sample Collection
                    </div>
                    <div className="text-sm text-gray-500">
                      {lab.homeCollection && !isScanWithHomeCollection 
                        ? 'Technician will visit your address' 
                        : isScanWithHomeCollection 
                          ? 'Not available for scans'
                          : 'Not available for this lab'}
                    </div>
                  </div>
                </button>
                
                <button
                  type="button"
                  className={`flex items-center p-4 border rounded-lg ${
                    locationType === 'lab' 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-300 hover:border-blue-300 hover:bg-blue-50'
                  } transition-colors`}
                  onClick={() => setLocationType('lab')}
                >
                  <Building size={24} className={`mr-3 ${locationType === 'lab' ? 'text-blue-600' : 'text-gray-500'}`} />
                  <div className="text-left">
                    <div className={`font-medium ${locationType === 'lab' ? 'text-blue-600' : 'text-gray-700'}`}>
                      Visit the Lab
                    </div>
                    <div className="text-sm text-gray-500">
                      Visit the diagnostic center
                    </div>
                  </div>
                </button>
              </div>
              
              {locationType === 'lab' && (
                <div className="mt-4 bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-start">
                    <MapPin size={18} className="text-blue-600 mt-0.5 mr-2 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-gray-800">{lab.name}</div>
                      <div className="text-sm text-gray-600">{lab.address}</div>
                    </div>
                  </div>
                </div>
              )}
              
              {locationType === 'home' && (
                <div className="mt-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Your Address
                  </label>
                  <textarea
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows={3}
                    placeholder="Enter your complete address"
                    required={locationType === 'home'}
                  />
                </div>
              )}
            </div>
            
            {/* Date and Time Selection */}
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">
                Appointment Date & Time
              </h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    <Calendar size={16} className="inline mr-1" />
                    Select Date
                  </label>
                  <select
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  >
                    <option value="">Select a date</option>
                    {availableDates.map(date => {
                      const displayDate = new Date(date).toLocaleDateString('en-US', {
                        weekday: 'short',
                        day: 'numeric',
                        month: 'short'
                      });
                      
                      return (
                        <option key={date} value={date}>
                          {displayDate}
                        </option>
                      );
                    })}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    <Clock size={16} className="inline mr-1" />
                    Select Time
                  </label>
                  <select
                    value={selectedTime}
                    onChange={(e) => setSelectedTime(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  >
                    <option value="">Select a time</option>
                    {availableTimeSlots.map(time => (
                      <option key={time} value={time}>{time}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            
            {/* Patient Information */}
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">
                Patient Information
              </h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter patient's full name"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={patientPhone}
                    onChange={(e) => setPatientPhone(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter phone number"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={patientEmail}
                    onChange={(e) => setPatientEmail(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter email address"
                    required
                  />
                </div>
              </div>
            </div>
            
            {/* Submit Button */}
            <button
              type="submit"
              disabled={!isFormValid() || bookingInProgress}
              className={`w-full flex items-center justify-center py-3 px-4 rounded-md text-white ${
                isFormValid() && !bookingInProgress
                  ? 'bg-blue-600 hover:bg-blue-700'
                  : 'bg-gray-400 cursor-not-allowed'
              } transition-colors`}
            >
              {bookingInProgress ? (
                <>
                  <Loader2 size={20} className="animate-spin mr-2" />
                  Processing...
                </>
              ) : (
                <>
                  <CreditCard size={20} className="mr-2" />
                  Proceed to Payment
                </>
              )}
            </button>
          </form>
        </div>
        
        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6 sticky top-20">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Appointment Summary
            </h2>
            
            <div className="border-b border-gray-200 pb-4 mb-4">
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Test:</span>
                <span className="font-medium text-gray-800">{test.name}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Lab:</span>
                <span className="font-medium text-gray-800">{lab.name}</span>
              </div>
              {selectedDate && (
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600">Date:</span>
                  <span className="font-medium text-gray-800">
                    {new Date(selectedDate).toLocaleDateString('en-US', {
                      weekday: 'short',
                      day: 'numeric',
                      month: 'short'
                    })}
                  </span>
                </div>
              )}
              {selectedTime && (
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600">Time:</span>
                  <span className="font-medium text-gray-800">{selectedTime}</span>
                </div>
              )}
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Location:</span>
                <span className="font-medium text-gray-800">
                  {locationType === 'home' ? 'Home Collection' : 'Visit Lab'}
                </span>
              </div>
            </div>
            
            <div className="pb-4 mb-4">
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Test Price:</span>
                <span className="font-medium text-gray-800">₹{lab.price}</span>
              </div>
              
              {locationType === 'home' && (
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600">Home Collection Fee:</span>
                  <span className="font-medium text-gray-800">₹0</span>
                </div>
              )}
              
              <div className="flex justify-between text-lg font-bold mt-4">
                <span className="text-gray-800">Total:</span>
                <span className="text-blue-600">₹{lab.price}</span>
              </div>
            </div>
            
            <div className="text-sm text-gray-500 bg-blue-50 p-3 rounded-md">
              <p>
                Your report will be ready within {lab.reportTime} after sample collection. You'll receive an email notification once it's ready.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingPage;