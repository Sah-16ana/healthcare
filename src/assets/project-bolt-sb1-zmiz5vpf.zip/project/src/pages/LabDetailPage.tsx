import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, MapPin, Clock, Star, Check, Phone, Mail, Calendar } from 'lucide-react';
import { mockApi } from '../data/mockData';
import { Test, Lab } from '../types';
import { Loader2 } from 'lucide-react';

const LabDetailPage = () => {
  const { labId, testId } = useParams<{ labId: string; testId: string }>();
  const [test, setTest] = useState<Test | null>(null);
  const [lab, setLab] = useState<Lab | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      if (!testId || !labId) return;
      
      setLoading(true);
      try {
        const [testData, labData] = await Promise.all([
          mockApi.getTestById(testId),
          mockApi.getLabById(labId)
        ]);
        
        if (testData) {
          setTest(testData);
        }
        
        if (labData) {
          setLab(labData);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [testId, labId]);

  const handleBookAppointment = () => {
    if (testId && labId) {
      navigate(`/booking/${labId}/${testId}`);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 size={40} className="animate-spin text-blue-600" />
      </div>
    );
  }

  if (!test || !lab) {
    return (
      <div className="text-center py-12">
        <p className="text-lg text-gray-600">Information not found</p>
        <Link to="/" className="text-blue-600 hover:underline mt-4 inline-block">
          Go back to home
        </Link>
      </div>
    );
  }

  return (
    <div>
      {/* Back Button */}
      <Link to={`/labs/${testId}`} className="flex items-center text-gray-600 mb-6 hover:text-blue-600">
        <ArrowLeft size={20} className="mr-1" />
        <span>Back to Labs List</span>
      </Link>
      
      {/* Lab Info */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex flex-wrap justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">{lab.name}</h1>
            <div className="flex items-center text-sm text-gray-600 mb-2">
              <MapPin size={16} className="mr-1" />
              <span>{lab.address}</span>
            </div>
            
            <div className="flex items-center space-x-4 mb-4">
              <div className="flex items-center text-sm text-gray-600">
                <Clock size={16} className="mr-1" />
                <span>{lab.openingTime} - {lab.closingTime}</span>
              </div>
              
              <div className="flex items-center bg-green-50 px-2 py-1 rounded">
                <Star size={14} className="text-green-600 mr-1" />
                <span className="text-sm font-medium text-green-800">{lab.rating}/5</span>
              </div>
            </div>
          </div>
          
          <div className="mt-4 sm:mt-0 flex items-center space-x-4">
            <a 
              href={`tel:+919876543210`} 
              className="flex items-center text-blue-600 hover:text-blue-800"
            >
              <Phone size={18} className="mr-1" />
              <span>Call Lab</span>
            </a>
            
            <a 
              href={`mailto:info@${lab.name.toLowerCase().replace(/\s+/g, '')}.com`} 
              className="flex items-center text-blue-600 hover:text-blue-800"
            >
              <Mail size={18} className="mr-1" />
              <span>Email</span>
            </a>
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-4 mt-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Facilities & Services</h2>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {lab.facilities.map((facility, index) => (
              <li key={index} className="flex items-start">
                <Check size={16} className="text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                <span className="text-gray-700">{facility}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      {/* Test Details Card */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-3">Test Details</h2>
        
        <div className="flex flex-wrap justify-between items-start">
          <div>
            <h3 className="font-medium text-gray-800 mb-1">{test.name}</h3>
            <div className="text-sm text-gray-600 mb-2">
              <span className="mr-3">Code: {test.code}</span>
              <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                {test.category}
              </span>
            </div>
            <div className="text-sm text-gray-600 mb-3">Report Time: {lab.reportTime}</div>
            <div className="text-sm text-gray-600">{test.requirements}</div>
          </div>
          
          <div className="mt-4 sm:mt-0">
            <div className="flex items-baseline">
              <span className="text-2xl font-bold text-gray-900">₹{lab.price}</span>
              {lab.originalPrice && (
                <span className="text-sm text-gray-500 line-through ml-2">
                  ₹{lab.originalPrice}
                </span>
              )}
            </div>
            {lab.originalPrice && (
              <span className="text-xs text-green-600">
                Save ₹{lab.originalPrice - lab.price}
              </span>
            )}
          </div>
        </div>
      </div>
      
      {/* Appointment Booking Card */}
      <div className="bg-blue-50 border border-blue-100 rounded-lg p-6 mb-6">
        <div className="flex items-start">
          <Calendar size={24} className="text-blue-600 mr-4 mt-1 flex-shrink-0" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Book Your Appointment
            </h3>
            <p className="text-gray-700 mb-4">
              Choose between home sample collection or visiting the lab for your {test.name}.
            </p>
            <button 
              onClick={handleBookAppointment}
              className="w-full sm:w-auto bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors"
            >
              Book Appointment
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LabDetailPage;