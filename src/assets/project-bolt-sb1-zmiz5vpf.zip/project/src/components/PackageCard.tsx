import React from 'react';
import { Link } from 'react-router-dom';
import { Plus, Check } from 'lucide-react';
import { Package } from '../types';
import { useCart } from '../context/CartContext';

interface PackageCardProps {
  packageItem: Package;
}

const PackageCard: React.FC<PackageCardProps> = ({ packageItem }) => {
  const { addPackageToCart, isPackageInCart } = useCart();
  const alreadyInCart = isPackageInCart(packageItem.id);

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:shadow-lg hover:-translate-y-1 border-2 border-blue-100">
      <div className="bg-blue-50 p-4 border-b border-blue-100">
        <h3 className="text-lg font-semibold text-gray-900">{packageItem.name}</h3>
        <div className="flex justify-between items-center mt-1">
          <div className="flex items-end">
            <span className="text-xl font-bold text-gray-900">₹{packageItem.price}</span>
            {packageItem.originalPrice && (
              <span className="text-sm text-gray-500 line-through ml-2">
                ₹{packageItem.originalPrice}
              </span>
            )}
          </div>
          <span className="bg-blue-600 text-white text-xs px-2 py-1 rounded-full">
            {packageItem.testCount} Tests
          </span>
        </div>
      </div>
      
      <div className="p-4">
        <p className="text-sm text-gray-600 mb-3">{packageItem.description}</p>
        
        <h4 className="font-medium text-gray-800 mb-2">Includes:</h4>
        <ul className="mb-4 space-y-1">
          {packageItem.includedTests.slice(0, 3).map((test, index) => (
            <li key={index} className="flex items-start">
              <Check size={16} className="text-green-500 mt-0.5 mr-2 flex-shrink-0" />
              <span className="text-sm text-gray-600">{test}</span>
            </li>
          ))}
          {packageItem.includedTests.length > 3 && (
            <li className="text-sm text-blue-600 ml-6 cursor-pointer hover:underline">
              + {packageItem.includedTests.length - 3} more
            </li>
          )}
        </ul>
        
        <div className="flex space-x-2 mt-4">
          <Link 
            to={`/test/${packageItem.id}`}
            className="text-blue-600 hover:text-blue-800 text-sm border border-blue-600 rounded-md px-3 py-1.5 flex-1 text-center"
          >
            View Details
          </Link>
          
          <button
            onClick={() => addPackageToCart(packageItem)}
            disabled={alreadyInCart}
            className={`flex items-center justify-center px-3 py-1.5 rounded-md text-sm flex-1 ${
              alreadyInCart 
                ? 'bg-gray-200 text-gray-600 cursor-not-allowed' 
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            {alreadyInCart ? (
              'Added to Cart'
            ) : (
              <>
                <Plus size={16} className="mr-1" />
                Add to Cart
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default PackageCard;