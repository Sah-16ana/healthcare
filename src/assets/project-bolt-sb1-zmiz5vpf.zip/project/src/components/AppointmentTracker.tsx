import React from 'react';
import { Check, Loader2 } from 'lucide-react';
import { AppointmentStatus } from '../types';

interface AppointmentTrackerProps {
  status: AppointmentStatus;
  dates: {
    confirmed: string;
    technicianOnWay?: string;
    sampleCollected?: string;
    processing?: string;
    reportReady?: string;
  };
}

const AppointmentTracker: React.FC<AppointmentTrackerProps> = ({ status, dates }) => {
  const steps = [
    { key: 'confirmed', label: 'Appointment Confirmed', date: dates.confirmed },
    { key: 'technicianOnWay', label: 'Technician On the Way', date: dates.technicianOnWay },
    { key: 'sampleCollected', label: 'Sample Collected', date: dates.sampleCollected },
    { key: 'processing', label: 'Test Processing', date: dates.processing },
    { key: 'reportReady', label: 'Report Ready', date: dates.reportReady }
  ];

  const getStepStatus = (stepKey: string) => {
    const statusOrder = ['confirmed', 'technicianOnWay', 'sampleCollected', 'processing', 'reportReady'];
    const currentIndex = statusOrder.indexOf(status);
    const stepIndex = statusOrder.indexOf(stepKey);
    
    if (stepIndex < currentIndex) {
      return 'completed';
    } else if (stepIndex === currentIndex) {
      return 'current';
    } else {
      return 'upcoming';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-6">Track Your Appointment</h2>
      
      <div className="relative">
        {steps.map((step, index) => {
          const stepStatus = getStepStatus(step.key);
          
          return (
            <div key={step.key} className="flex mb-8 last:mb-0">
              {/* Status icon */}
              <div className="relative flex-shrink-0">
                <div className={`h-10 w-10 rounded-full flex items-center justify-center border-2 ${
                  stepStatus === 'completed' 
                    ? 'bg-green-100 border-green-500' 
                    : stepStatus === 'current'
                      ? 'bg-blue-100 border-blue-500 animate-pulse' 
                      : 'bg-gray-100 border-gray-300'
                }`}>
                  {stepStatus === 'completed' ? (
                    <Check size={20} className="text-green-600" />
                  ) : stepStatus === 'current' ? (
                    <Loader2 size={20} className="text-blue-600 animate-spin" />
                  ) : (
                    <div className="h-3 w-3 rounded-full bg-gray-300"></div>
                  )}
                </div>
                
                {/* Connector Line */}
                {index < steps.length - 1 && (
                  <div className={`absolute top-10 left-1/2 -translate-x-1/2 w-0.5 h-8 ${
                    stepStatus === 'completed' ? 'bg-green-500' : 'bg-gray-300'
                  }`}></div>
                )}
              </div>
              
              {/* Content */}
              <div className="ml-4 flex-1">
                <h3 className={`font-medium ${
                  stepStatus === 'completed' 
                    ? 'text-green-700' 
                    : stepStatus === 'current'
                      ? 'text-blue-700' 
                      : 'text-gray-500'
                }`}>
                  {step.label}
                </h3>
                
                {step.date && (
                  <p className="text-sm text-gray-500 mt-1">
                    {step.date}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AppointmentTracker;