import React from 'react';
import { Link } from 'react-router-dom';
import { Plus, Check } from 'lucide-react';
import { Test, Package } from '../types';
import { useCart } from '../context/CartContext';

interface TestCardProps {
  item: Test | Package;
  showPackageDetails?: boolean;
}

const TestCard: React.FC<TestCardProps> = ({ item, showPackageDetails = false }) => {
  const { addToCart, addPackageToCart, isInCart, isPackageInCart } = useCart();
  const isPackage = item.type === 'package';
  const alreadyInCart = isPackage ? isPackageInCart(item.id) : isInCart(item.id);

  const handleAddToCart = () => {
    if (isPackage) {
      addPackageToCart(item as Package);
    } else {
      addToCart(item as Test);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:shadow-lg hover:-translate-y-1">
      <div className={`p-5 ${isPackage ? 'border-2 border-blue-100' : ''}`}>
        {isPackage && (
          <div className="bg-blue-50 -m-5 p-4 border-b border-blue-100 mb-4">
            <h3 className="text-lg font-semibold text-gray-900">{item.name}</h3>
            <div className="flex justify-between items-center mt-1">
              <div className="flex items-end">
                <span className="text-xl font-bold text-gray-900">₹{item.price}</span>
                {item.originalPrice && (
                  <span className="text-sm text-gray-500 line-through ml-2">
                    ₹{item.originalPrice}
                  </span>
                )}
              </div>
              {isPackage && (
                <span className="bg-blue-600 text-white text-xs px-2 py-1 rounded-full">
                  {(item as Package).testCount} Tests
                </span>
              )}
            </div>
          </div>
        )}

        {!isPackage && (
          <>
            <h3 className="text-lg font-medium text-gray-900 mb-2">{item.name}</h3>
            <div className="flex items-center text-sm text-gray-500 mb-3">
              <span className="mr-2">Code: {(item as Test).code}</span>
              <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                {(item as Test).category}
              </span>
            </div>
          </>
        )}
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{item.description}</p>
        
        {isPackage && showPackageDetails && (
          <>
            <h4 className="font-medium text-gray-800 mb-2">Includes:</h4>
            <ul className="mb-4 space-y-1">
              {(item as Package).includedTests.slice(0, 3).map((test, index) => (
                <li key={index} className="flex items-start">
                  <Check size={16} className="text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span className="text-sm text-gray-600">{test}</span>
                </li>
              ))}
              {(item as Package).includedTests.length > 3 && (
                <li className="text-sm text-blue-600 ml-6 cursor-pointer hover:underline">
                  + {(item as Package).includedTests.length - 3} more
                </li>
              )}
            </ul>
          </>
        )}
        
        <div className="flex items-center justify-between mt-4">
          {!isPackage && (
            <div className="flex items-end">
              <span className="text-xl font-bold text-gray-900">₹{item.price}</span>
              {item.originalPrice && (
                <span className="text-sm text-gray-500 line-through ml-2">
                  ₹{item.originalPrice}
                </span>
              )}
            </div>
          )}
          
          <div className="flex space-x-2 ml-auto">
            <Link 
              to={`/test/${item.id}`}
              className="text-blue-600 hover:text-blue-800 text-sm border border-blue-600 rounded-md px-3 py-1"
            >
              Details
            </Link>
            
            <button
              onClick={handleAddToCart}
              disabled={alreadyInCart}
              className={`flex items-center px-3 py-1 rounded-md text-sm ${
                alreadyInCart 
                  ? 'bg-gray-200 text-gray-600 cursor-not-allowed' 
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              {alreadyInCart ? (
                'Added'
              ) : (
                <>
                  <Plus size={16} className="mr-1" />
                  Add
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestCard;