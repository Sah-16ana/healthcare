import React, { useState } from 'react';

interface TabNavigationProps {
  activeTab: 'tests' | 'scans';
  onTabChange: (tab: 'tests' | 'scans') => void;
}

const TabNavigation: React.FC<TabNavigationProps> = ({ activeTab, onTabChange }) => {
  return (
    <div className="border-b border-gray-200 mb-6">
      <div className="flex -mb-px">
        <button
          className={`py-4 px-6 text-center font-medium text-sm border-b-2 ${
            activeTab === 'tests'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
          }`}
          onClick={() => onTabChange('tests')}
        >
          Tests
        </button>
        <button
          className={`py-4 px-6 text-center font-medium text-sm border-b-2 ${
            activeTab === 'scans'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
          }`}
          onClick={() => onTabChange('scans')}
        >
          Scans
        </button>
      </div>
    </div>
  );
};

export default TabNavigation;