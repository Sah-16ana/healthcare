import React, { useState } from 'react';
import { X, Upload, Check } from 'lucide-react';

interface UploadPrescriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const UploadPrescriptionModal: React.FC<UploadPrescriptionModalProps> = ({ isOpen, onClose }) => {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) return;
    
    setUploading(true);
    
    // Simulate upload
    setTimeout(() => {
      setUploading(false);
      setUploadSuccess(true);
      
      // Close modal after success
      setTimeout(() => {
        onClose();
        setFile(null);
        setUploadSuccess(false);
      }, 1500);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md overflow-hidden">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold text-gray-800">Upload Prescription</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6">
          {!uploadSuccess ? (
            <>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center mb-6">
                {file ? (
                  <div className="text-gray-700">
                    <Check size={48} className="mx-auto mb-2 text-green-500" />
                    <p className="font-medium">File selected:</p> 
                    <p className="text-sm">{file.name}</p>
                  </div>
                ) : (
                  <div className="text-gray-500">
                    <Upload size={48} className="mx-auto mb-2" />
                    <p className="mb-2">Drag and drop your prescription here</p>
                    <p className="text-sm mb-4">or</p>
                    <label className="bg-blue-600 text-white py-2 px-4 rounded-md cursor-pointer hover:bg-blue-700 transition">
                      Browse Files
                      <input 
                        type="file" 
                        accept="image/*, application/pdf" 
                        className="hidden" 
                        onChange={handleFileChange}
                      />
                    </label>
                  </div>
                )}
              </div>
              
              <div className="text-sm text-gray-500 mb-6">
                <p className="mb-2">Accepted file formats: JPG, PNG, PDF</p>
                <p>Maximum file size: 10MB</p>
              </div>
              
              <button 
                type="submit" 
                className={`w-full py-2 px-4 rounded-md ${
                  file && !uploading 
                    ? 'bg-blue-600 text-white hover:bg-blue-700' 
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                } transition flex items-center justify-center`}
                disabled={!file || uploading}
              >
                {uploading ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Uploading...
                  </>
                ) : 'Upload Prescription'}
              </button>
            </>
          ) : (
            <div className="text-center py-6">
              <div className="mx-auto bg-green-100 rounded-full p-3 w-16 h-16 flex items-center justify-center mb-4">
                <Check size={36} className="text-green-600" />
              </div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">Upload Successful!</h3>
              <p className="text-gray-600">Your prescription has been uploaded successfully.</p>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default UploadPrescriptionModal;