import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, ShoppingCart, Upload, Menu, X, Beaker, Activity } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useSearch } from '../context/SearchContext';
import UploadPrescriptionModal from './UploadPrescriptionModal';

const Header = () => {
  const { cart } = useCart();
  const { searchQuery, setSearchQuery, performSearch } = useSearch();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isPrescriptionModalOpen, setIsPrescriptionModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'tests' | 'scans'>('tests');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch();
    navigate('/');
  };

  const handleTabChange = (tab: 'tests' | 'scans') => {
    setActiveTab(tab);
    // You can add additional logic here if needed when tabs change
  };

  return (
    <div className="sticky top-0 z-50 bg-white shadow-md">
      <header className="container mx-auto px-4 max-w-6xl">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link to="/" className="text-2xl font-bold text-blue-600 flex items-center">
            <Beaker className="mr-2" />
            <span>MediLabs</span>
          </Link>

          {/* Search Bar - Hidden on mobile */}
          <form 
            onSubmit={handleSearchSubmit}
            className="hidden md:flex items-center flex-1 max-w-xl mx-4 relative"
          >
            <input
              type="text"
              placeholder="Search for tests, scans..."
              className="w-full py-2 px-4 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button 
              type="submit"
              className="absolute right-3 text-gray-500 hover:text-blue-600"
            >
              <Search size={20} />
            </button>
          </form>

          {/* Nav Items - Desktop */}
          <div className="hidden md:flex items-center space-x-6">
            <button 
              onClick={() => setIsPrescriptionModalOpen(true)}
              className="flex items-center text-gray-700 hover:text-blue-600"
            >
              <Upload size={20} className="mr-1" />
              <span>Upload Prescription</span>
            </button>
            
            <Link to="/cart" className="flex items-center text-gray-700 hover:text-blue-600 relative">
              <ShoppingCart size={20} className="mr-1" />
              <span>Cart</span>
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-blue-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cart.length}
                </span>
              )}
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-700"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Search - Visible only on mobile */}
        <div className="md:hidden pb-4">
          <form 
            onSubmit={handleSearchSubmit}
            className="flex items-center relative"
          >
            <input
              type="text"
              placeholder="Search for tests, scans..."
              className="w-full py-2 px-4 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button 
              type="submit"
              className="absolute right-3 text-gray-500 hover:text-blue-600"
            >
              <Search size={20} />
            </button>
          </form>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <div className="flex flex-col space-y-4">
              <button 
                onClick={() => {
                  setIsPrescriptionModalOpen(true);
                  setIsMenuOpen(false);
                }}
                className="flex items-center text-gray-700 hover:text-blue-600"
              >
                <Upload size={20} className="mr-2" />
                <span>Upload Prescription</span>
              </button>
              
              <Link 
                to="/cart" 
                className="flex items-center text-gray-700 hover:text-blue-600"
                onClick={() => setIsMenuOpen(false)}
              >
                <ShoppingCart size={20} className="mr-2" />
                <span>Cart</span>
                {cart.length > 0 && (
                  <span className="ml-2 bg-blue-600 text-white text-xs rounded-full px-2 py-1">
                    {cart.length}
                  </span>
                )}
              </Link>
            </div>
          </div>
        )}
      </header>

      {/* Tabs Navigation */}
      <div className="bg-gray-50 border-t border-gray-200">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="flex -mb-px">
            <button
              className={`py-4 px-6 text-center font-medium text-sm border-b-2 ${
                activeTab === 'tests'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
              onClick={() => handleTabChange('tests')}
            >
              <Beaker size={16} className="inline mr-2" />
              Tests
            </button>
            <button
              className={`py-4 px-6 text-center font-medium text-sm border-b-2 ${
                activeTab === 'scans'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
              onClick={() => handleTabChange('scans')}
            >
              <Activity size={16} className="inline mr-2" />
              Scans
            </button>
          </div>
        </div>
      </div>

      {/* Prescription Upload Modal */}
      <UploadPrescriptionModal 
        isOpen={isPrescriptionModalOpen}
        onClose={() => setIsPrescriptionModalOpen(false)}
      />
    </div>
  );
};

export default Header;