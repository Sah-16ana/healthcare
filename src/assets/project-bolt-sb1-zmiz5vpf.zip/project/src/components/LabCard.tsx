import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Clock, Star, Check } from 'lucide-react';
import { Lab } from '../types';

interface LabCardProps {
  lab: Lab;
  testId: string;
}

const LabCard: React.FC<LabCardProps> = ({ lab, testId }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:shadow-lg hover:-translate-y-1">
      <div className="p-5">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-1">{lab.name}</h3>
            <div className="flex items-center text-sm text-gray-500 mb-2">
              <MapPin size={14} className="mr-1" />
              <span>{lab.area}, {lab.city}</span>
            </div>
          </div>
          
          <div className="flex items-center bg-green-50 px-2 py-1 rounded">
            <Star size={14} className="text-green-600 mr-1" />
            <span className="text-sm font-medium text-green-800">{lab.rating}/5</span>
          </div>
        </div>
        
        <div className="mt-3 space-y-2 text-sm">
          <div className="flex items-start">
            <Check size={16} className="text-green-500 mt-0.5 mr-2 flex-shrink-0" />
            <span className="text-gray-600">NABL Accredited Laboratory</span>
          </div>
          <div className="flex items-start">
            <Check size={16} className="text-green-500 mt-0.5 mr-2 flex-shrink-0" />
            <span className="text-gray-600">{lab.homeCollection ? 'Home sample collection available' : 'Visit lab for sample collection'}</span>
          </div>
          <div className="flex items-start">
            <Clock size={16} className="text-blue-500 mt-0.5 mr-2 flex-shrink-0" />
            <span className="text-gray-600">Reports in {lab.reportTime}</span>
          </div>
        </div>
        
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
          <div className="flex items-end">
            <span className="text-lg font-bold text-gray-900">₹{lab.price}</span>
            {lab.originalPrice && (
              <span className="text-sm text-gray-500 line-through ml-2">
                ₹{lab.originalPrice}
              </span>
            )}
          </div>
          
          <Link 
            to={`/lab/${lab.id}/${testId}`}
            className="bg-blue-600 text-white hover:bg-blue-700 transition-colors px-4 py-2 rounded-md text-sm"
          >
            Select Lab
          </Link>
        </div>
      </div>
    </div>
  );
};

export default LabCard;