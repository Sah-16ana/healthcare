export interface Test {
  id: string;
  name: string;
  code: string;
  category: string;
  type: 'test' | 'scan' | string;
  description: string;
  price: number;
  originalPrice?: number;
  requirements: string;
  reportTime: string;
}

export interface Package {
  id: string;
  name: string;
  type: 'package';
  description: string;
  price: number;
  originalPrice?: number;
  testCount: number;
  includedTests: string[];
  reportTime: string;
}

export interface Lab {
  id: string;
  name: string;
  area: string;
  city: string;
  address: string;
  rating: number;
  price: number;
  originalPrice?: number;
  homeCollection: boolean;
  reportTime: string;
  facilities: string[];
  openingTime: string;
  closingTime: string;
}

export type AppointmentStatus = 'confirmed' | 'technicianOnWay' | 'sampleCollected' | 'processing' | 'reportReady';

export interface Appointment {
  id: string;
  testId: string;
  labId: string;
  status: AppointmentStatus;
  type: 'home' | 'lab';
  date: string;
  time: string;
  address?: string;
  paymentStatus: 'pending' | 'paid';
  amount: number;
  patientName: string;
  patientPhone: string;
  patientEmail: string;
  statusDates: {
    confirmed: string;
    technicianOnWay?: string;
    sampleCollected?: string;
    processing?: string;
    reportReady?: string;
  };
}