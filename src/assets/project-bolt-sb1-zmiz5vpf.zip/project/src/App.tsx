import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import TestDetailPage from './pages/TestDetailPage';
import LabListPage from './pages/LabListPage';
import LabDetailPage from './pages/LabDetailPage';
import BookingPage from './pages/BookingPage';
import PaymentPage from './pages/PaymentPage';
import SuccessPage from './pages/SuccessPage';
import TrackingPage from './pages/TrackingPage';
import CartPage from './pages/CartPage';
import { CartProvider } from './context/CartContext';
import { SearchProvider } from './context/SearchContext';

function App() {
  return (
    <Router>
      <SearchProvider>
        <CartProvider>
          <div className="min-h-screen bg-gray-50">
            <Header />
            <main className="container mx-auto px-4 py-4 max-w-6xl">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/test/:id" element={<TestDetailPage />} />
                <Route path="/labs/:testId" element={<LabListPage />} />
                <Route path="/lab/:labId/:testId" element={<LabDetailPage />} />
                <Route path="/booking/:labId/:testId" element={<BookingPage />} />
                <Route path="/payment/:appointmentId" element={<PaymentPage />} />
                <Route path="/success/:appointmentId" element={<SuccessPage />} />
                <Route path="/tracking/:appointmentId" element={<TrackingPage />} />
                <Route path="/cart" element={<CartPage />} />
              </Routes>
            </main>
          </div>
        </CartProvider>
      </SearchProvider>
    </Router>
  );
}

export default App;