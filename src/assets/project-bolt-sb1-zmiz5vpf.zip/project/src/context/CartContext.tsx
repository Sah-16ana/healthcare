import React, { createContext, useState, useContext, useEffect } from 'react';
import { Test, Package } from '../types';

interface CartContextType {
  cart: (Test | Package)[];
  addToCart: (test: Test) => void;
  addPackageToCart: (packageItem: Package) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  isInCart: (id: string) => boolean;
  isPackageInCart: (id: string) => boolean;
  getTotalPrice: () => number;
}

const CartContext = createContext<CartContextType>({
  cart: [],
  addToCart: () => {},
  addPackageToCart: () => {},
  removeFromCart: () => {},
  clearCart: () => {},
  isInCart: () => false,
  isPackageInCart: () => false,
  getTotalPrice: () => 0
});

export const useCart = () => useContext(CartContext);

interface CartProviderProps {
  children: React.ReactNode;
}

export const CartProvider: React.FC<CartProviderProps> = ({ children }) => {
  const [cart, setCart] = useState<(Test | Package)[]>([]);

  // Load cart from localStorage on initial load
  useEffect(() => {
    const savedCart = localStorage.getItem('medilabs-cart');
    if (savedCart) {
      try {
        setCart(JSON.parse(savedCart));
      } catch (error) {
        console.error('Failed to parse cart from localStorage', error);
      }
    }
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('medilabs-cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (test: Test) => {
    if (!isInCart(test.id)) {
      setCart([...cart, { ...test, type: 'test' }]);
    }
  };

  const addPackageToCart = (packageItem: Package) => {
    if (!isPackageInCart(packageItem.id)) {
      setCart([...cart, { ...packageItem, type: 'package' }]);
    }
  };

  const removeFromCart = (id: string) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const clearCart = () => {
    setCart([]);
  };

  const isInCart = (id: string) => {
    return cart.some(item => item.id === id && item.type === 'test');
  };

  const isPackageInCart = (id: string) => {
    return cart.some(item => item.id === id && item.type === 'package');
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price, 0);
  };

  return (
    <CartContext.Provider 
      value={{ 
        cart, 
        addToCart, 
        addPackageToCart,
        removeFromCart, 
        clearCart, 
        isInCart,
        isPackageInCart,
        getTotalPrice 
      }}
    >
      {children}
    </CartContext.Provider>
  );
};