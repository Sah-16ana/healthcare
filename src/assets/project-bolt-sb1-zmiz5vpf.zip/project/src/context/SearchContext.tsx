import React, { createContext, useState, useContext } from 'react';
import { mockTests, mockScans } from '../data/mockData';
import { Test } from '../types';

interface SearchContextType {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  searchResults: Test[];
  performSearch: () => void;
  isSearching: boolean;
}

const SearchContext = createContext<SearchContextType>({
  searchQuery: '',
  setSearchQuery: () => {},
  searchResults: [],
  performSearch: () => {},
  isSearching: false
});

export const useSearch = () => useContext(SearchContext);

interface SearchProviderProps {
  children: React.ReactNode;
}

export const SearchProvider: React.FC<SearchProviderProps> = ({ children }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Test[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const performSearch = () => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    setIsSearching(true);

    // Simulate API call with timeout
    setTimeout(() => {
      const query = searchQuery.toLowerCase();
      
      // Combine tests and scans, then filter
      const allItems = [...mockTests, ...mockScans];
      const results = allItems.filter(
        item => 
          item.name.toLowerCase().includes(query) || 
          item.description.toLowerCase().includes(query) ||
          (item.category && item.category.toLowerCase().includes(query))
      );
      
      setSearchResults(results);
      setIsSearching(false);
    }, 500);
  };

  return (
    <SearchContext.Provider 
      value={{ 
        searchQuery, 
        setSearchQuery, 
        searchResults, 
        performSearch,
        isSearching
      }}
    >
      {children}
    </SearchContext.Provider>
  );
};