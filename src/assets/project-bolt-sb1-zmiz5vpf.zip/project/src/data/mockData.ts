import { Test, Package, Lab, Appointment } from '../types';

// Mock Tests Data
export const mockTests: Test[] = [
  {
    id: 't1',
    name: 'Complete Blood Count (CBC)',
    code: 'CBC001',
    category: 'Hematology',
    type: 'test',
    description: 'Measures different components and features of your blood including red blood cells, white blood cells, and platelets.',
    price: 599,
    originalPrice: 799,
    requirements: 'Fasting not required',
    reportTime: '24 hours'
  },
  {
    id: 't2',
    name: 'Blood Glucose Fasting',
    code: 'BG001',
    category: 'Diabetes',
    type: 'test',
    description: 'Measures the amount of glucose in your blood to diagnose and monitor diabetes.',
    price: 299,
    requirements: '8 hours fasting required',
    reportTime: '24 hours'
  },
  {
    id: 't3',
    name: 'Lipid Profile',
    code: 'LP001',
    category: 'Cardiac',
    type: 'test',
    description: 'Measures the amount of cholesterol and fats in your blood to assess risk of heart disease.',
    price: 799,
    originalPrice: 999,
    requirements: '12 hours fasting required',
    reportTime: '24 hours'
  },
  {
    id: 't4',
    name: 'Thyroid Profile',
    code: 'TH001',
    category: 'Endocrinology',
    type: 'test',
    description: 'Measures the levels of thyroid hormones to diagnose thyroid disorders.',
    price: 899,
    requirements: 'Fasting not required',
    reportTime: '24-48 hours'
  },
  {
    id: 't5',
    name: 'Liver Function Test',
    code: 'LFT001',
    category: 'Gastroenterology',
    type: 'test',
    description: 'Measures the levels of proteins, enzymes, and substances in your blood to evaluate liver function.',
    price: 799,
    requirements: 'Fasting not required',
    reportTime: '24 hours'
  },
  {
    id: 't6',
    name: 'Kidney Function Test',
    code: 'KFT001',
    category: 'Nephrology',
    type: 'test',
    description: 'Measures the levels of various substances in your blood to evaluate kidney function.',
    price: 799,
    requirements: 'Fasting not required',
    reportTime: '24 hours'
  },
];

// Mock Scans Data
export const mockScans: Test[] = [
  {
    id: 's1',
    name: 'X-Ray Chest',
    code: 'XRC001',
    category: 'Radiology',
    type: 'scan',
    description: 'Uses electromagnetic waves to create images of the structures in and around your chest, including your heart, lungs, and bones.',
    price: 799,
    requirements: 'No special preparation required',
    reportTime: '24 hours'
  },
  {
    id: 's2',
    name: 'Ultrasound Abdomen',
    code: 'USA001',
    category: 'Radiology',
    type: 'scan',
    description: 'Uses sound waves to create images of structures inside your abdomen, such as your liver, gallbladder, and pancreas.',
    price: 1499,
    originalPrice: 1999,
    requirements: '6 hours fasting required',
    reportTime: '24-48 hours'
  },
  {
    id: 's3',
    name: 'CT Scan Brain',
    code: 'CTB001',
    category: 'Radiology',
    type: 'scan',
    description: 'Uses X-rays and computer processing to create detailed images of your brain.',
    price: 3999,
    requirements: 'No special preparation required',
    reportTime: '24-48 hours'
  },
  {
    id: 's4',
    name: 'MRI Knee Joint',
    code: 'MRK001',
    category: 'Radiology',
    type: 'scan',
    description: 'Uses magnetic fields and radio waves to create detailed images of your knee joint.',
    price: 5999,
    originalPrice: 6999,
    requirements: 'No special preparation required',
    reportTime: '48 hours'
  },
];

// Mock Packages Data
export const mockPackages: Package[] = [
  {
    id: 'p1',
    name: 'Basic Health Checkup',
    type: 'package',
    description: 'A comprehensive package for basic health screening. Ideal for routine annual checkups.',
    price: 1499,
    originalPrice: 1999,
    testCount: 10,
    includedTests: [
      'Complete Blood Count',
      'Blood Glucose Fasting',
      'Lipid Profile',
      'Liver Function Test',
      'Kidney Function Test',
      'Urine Routine & Microscopy',
      'Blood Pressure',
      'ECG',
      'Consultation with Physician',
      'Digital Report'
    ],
    reportTime: '48 hours'
  },
  {
    id: 'p2',
    name: 'Advanced Health Checkup',
    type: 'package',
    description: 'A comprehensive package for advanced health screening. Includes everything from Basic Health Checkup plus additional tests.',
    price: 2999,
    originalPrice: 3999,
    testCount: 15,
    includedTests: [
      'Complete Blood Count',
      'Blood Glucose Fasting',
      'Lipid Profile',
      'Liver Function Test',
      'Kidney Function Test',
      'Thyroid Profile',
      'Vitamin D',
      'Vitamin B12',
      'Urine Routine & Microscopy',
      'Blood Pressure',
      'ECG',
      'Chest X-Ray',
      'Consultation with Physician',
      'Digital Report',
      'Follow-up Consultation'
    ],
    reportTime: '72 hours'
  },
  {
    id: 'p3',
    name: 'Diabetes Checkup',
    type: 'package',
    description: 'A focused package for diabetes screening and monitoring. Ideal for those at risk or managing diabetes.',
    price: 1299,
    testCount: 7,
    includedTests: [
      'Blood Glucose Fasting',
      'HbA1c',
      'Lipid Profile',
      'Kidney Function Test',
      'Urine Microalbumin',
      'Consultation with Diabetologist',
      'Digital Report'
    ],
    reportTime: '48 hours'
  },
];

// Mock Labs Data
export const mockLabs: Lab[] = [
  {
    id: 'lab1',
    name: 'MediLabs Diagnostics',
    area: 'Malad West',
    city: 'Mumbai',
    address: '123, Linking Road, Malad West, Mumbai - 400064',
    rating: 4.5,
    price: 599,
    originalPrice: 799,
    homeCollection: true,
    reportTime: '24 hours',
    facilities: [
      'NABL Accredited',
      'Home Collection Available',
      'Digital Reports',
      'Expert Pathologists'
    ],
    openingTime: '7:00 AM',
    closingTime: '9:00 PM'
  },
  {
    id: 'lab2',
    name: 'HealthCare Pathology',
    area: 'Andheri East',
    city: 'Mumbai',
    address: '456, Andheri East, Mumbai - 400069',
    rating: 4.2,
    price: 649,
    homeCollection: true,
    reportTime: '24-48 hours',
    facilities: [
      'ISO Certified',
      'Home Collection Available',
      'Digital Reports',
      'Expert Pathologists',
      'Multiple Locations'
    ],
    openingTime: '6:30 AM',
    closingTime: '8:00 PM'
  },
  {
    id: 'lab3',
    name: 'City Scan Center',
    area: 'Bandra West',
    city: 'Mumbai',
    address: '789, Bandra West, Mumbai - 400050',
    rating: 4.7,
    price: 699,
    originalPrice: 899,
    homeCollection: false,
    reportTime: '24 hours',
    facilities: [
      'NABL & ISO Certified',
      'Digital Reports',
      'Expert Radiologists',
      'State-of-the-art Equipment'
    ],
    openingTime: '8:00 AM',
    closingTime: '8:00 PM'
  },
];

// Mock Appointments Data
export const mockAppointments: Record<string, Appointment> = {
  'apt1': {
    id: 'apt1',
    testId: 't1',
    labId: 'lab1',
    status: 'reportReady',
    type: 'home',
    date: '2023-05-16',
    time: '10:00 AM',
    address: '123, ABC Apartments, XYZ Road, Mumbai - 400001',
    paymentStatus: 'paid',
    amount: 599,
    patientName: 'John Doe',
    patientPhone: '9876543210',
    patientEmail: 'john@example.com',
    statusDates: {
      confirmed: 'Wed, 16th Mar',
      technicianOnWay: 'Wed, 16th Mar',
      sampleCollected: 'Wed, 16th Mar',
      processing: 'Wed, 17th Mar',
      reportReady: 'Wed, 17th Mar'
    }
  },
  'apt2': {
    id: 'apt2',
    testId: 's2',
    labId: 'lab3',
    status: 'confirmed',
    type: 'lab',
    date: '2023-05-18',
    time: '11:30 AM',
    paymentStatus: 'paid',
    amount: 1499,
    patientName: 'Jane Smith',
    patientPhone: '9876543211',
    patientEmail: 'jane@example.com',
    statusDates: {
      confirmed: 'Wed, 16th Mar'
    }
  }
};

// Function to simulate API calls
export const mockApi = {
  getTests: () => {
    return new Promise<Test[]>((resolve) => {
      setTimeout(() => resolve(mockTests), 500);
    });
  },
  
  getScans: () => {
    return new Promise<Test[]>((resolve) => {
      setTimeout(() => resolve(mockScans), 500);
    });
  },
  
  getPackages: () => {
    return new Promise<Package[]>((resolve) => {
      setTimeout(() => resolve(mockPackages), 500);
    });
  },
  
  getTestById: (id: string) => {
    return new Promise<Test | undefined>((resolve) => {
      const test = [...mockTests, ...mockScans].find(t => t.id === id);
      setTimeout(() => resolve(test), 500);
    });
  },
  
  getLabsForTest: (testId: string) => {
    return new Promise<Lab[]>((resolve) => {
      // In a real app, you'd filter labs that offer the specific test
      // For mock data, we'll just return all labs
      setTimeout(() => resolve(mockLabs), 500);
    });
  },
  
  getLabById: (labId: string) => {
    return new Promise<Lab | undefined>((resolve) => {
      const lab = mockLabs.find(l => l.id === labId);
      setTimeout(() => resolve(lab), 500);
    });
  },
  
  createAppointment: (appointmentData: Partial<Appointment>) => {
    return new Promise<Appointment>((resolve) => {
      // Create a new appointment with a unique ID
      const newId = `apt${Object.keys(mockAppointments).length + 1}`;
      const newAppointment: Appointment = {
        id: newId,
        testId: appointmentData.testId || '',
        labId: appointmentData.labId || '',
        status: 'confirmed',
        type: appointmentData.type || 'home',
        date: appointmentData.date || '',
        time: appointmentData.time || '',
        address: appointmentData.address || '',
        paymentStatus: 'pending',
        amount: appointmentData.amount || 0,
        patientName: appointmentData.patientName || '',
        patientPhone: appointmentData.patientPhone || '',
        patientEmail: appointmentData.patientEmail || '',
        statusDates: {
          confirmed: new Date().toLocaleDateString('en-US', { weekday: 'short', day: 'numeric', month: 'short' })
        }
      };
      
      // Add to mock data
      mockAppointments[newId] = newAppointment;
      
      setTimeout(() => resolve(newAppointment), 500);
    });
  },
  
  processPayment: (appointmentId: string) => {
    return new Promise<Appointment>((resolve) => {
      const appointment = mockAppointments[appointmentId];
      if (appointment) {
        appointment.paymentStatus = 'paid';
        setTimeout(() => resolve(appointment), 1000);
      } else {
        throw new Error('Appointment not found');
      }
    });
  },
  
  getAppointmentById: (appointmentId: string) => {
    return new Promise<Appointment | undefined>((resolve) => {
      const appointment = mockAppointments[appointmentId];
      setTimeout(() => resolve(appointment), 500);
    });
  },
  
  updateAppointmentStatus: (appointmentId: string, status: string) => {
    return new Promise<Appointment>((resolve) => {
      const appointment = mockAppointments[appointmentId];
      if (appointment) {
        appointment.status = status as any;
        setTimeout(() => resolve(appointment), 500);
      } else {
        throw new Error('Appointment not found');
      }
    });
  }
};